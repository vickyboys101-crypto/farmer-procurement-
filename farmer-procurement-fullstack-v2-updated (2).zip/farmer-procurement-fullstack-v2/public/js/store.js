/*
 * store.js (frontend)
 * Thin REST client for the real backend (Express + SQLite) — replaces
 * the old localStorage-backed prototype "database". All state now
 * lives in server/kalam.db, so the Farmer view and Centre Staff view
 * (even on two different devices) see the same live bookings.
 */
const API = "/api";

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

const Store = {
  states: [],
  slots: [],
  centres: [],

  /** Load reference data once at startup and cache it. */
  async init() {
    const [states, slots, centres] = await Promise.all([
      getJSON(`${API}/states`),
      getJSON(`${API}/slots`),
      getJSON(`${API}/centres`),
    ]);
    this.states = states;
    this.slots = slots;
    this.centres = centres;
  },

  centresByState(state) {
    return this.centres.filter(c => c.state === state);
  },

  /** Crops actually grown/procured in a given state, from the server. */
  async cropsByState(state) {
    return getJSON(`${API}/crops?state=${encodeURIComponent(state)}`);
  },

  /** Centres nearest to a GPS point, strictly limited to the requested radius. */
  async centresNearby(lat, lng, radiusKm = 100) {
    return getJSON(`${API}/centres/nearby?lat=${lat}&lng=${lng}&radius=${radiusKm}`);
  },

  async reverseGeocode(lat, lng) {
    return getJSON(`${API}/location/reverse?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lng)}`);
  },

  async ipLocation() {
    return getJSON(`${API}/location/ip`);
  },

  /** Ranked centre/slot options for a state, live from the server. */
  async rankOptions(state) {
    return getJSON(`${API}/rank?state=${encodeURIComponent(state)}`);
  },

  /** Ranked centre/slot options restricted to a specific set of centre ids
   *  (used for the "centres near me" flow). */
  async rankOptionsForCentres(centreIds) {
    return getJSON(`${API}/rank?centreIds=${encodeURIComponent(centreIds.join(","))}`);
  },

  async addBooking({ centreId, slotId, farmer, state, areaVillage, crop, qty, locationLat, locationLng, voiceNote }) {
    const res = await fetch(`${API}/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        centreId, slotId, farmer, state, areaVillage, crop, qty,
        village: areaVillage, locationLat, locationLng, voiceNote,
      }),
    });
    if (!res.ok) throw new Error("Booking failed");
    return res.json(); // { token }
  },

  async getBooking(token) {
    return getJSON(`${API}/bookings/${encodeURIComponent(token)}`);
  },

  async advanceStatus(token) {
    const res = await fetch(`${API}/bookings/${encodeURIComponent(token)}/advance`, { method: "POST" });
    if (!res.ok) throw new Error("Advance failed");
    return res.json();
  },

  async getCentreQueue(centreId) {
    return getJSON(`${API}/admin/centre/${encodeURIComponent(centreId)}`);
  },

  async addTransportBooking(details) {
    const res = await fetch(`${API}/transport/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(details),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || "Transport booking failed");
    return body;
  },

  async getTransportTracking(bookingCode) {
    return getJSON(`${API}/transport/bookings/${encodeURIComponent(bookingCode)}/tracking`);
  },

  /** Driver app hook: publish a GPS ping for the farmer tracking screen. */
  async sendDriverLocation(bookingCode, { vehicleToken, lat, lng, accuracy }) {
    const res = await fetch(`${API}/transport/bookings/${encodeURIComponent(bookingCode)}/location`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vehicleToken, lat, lng, accuracy }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || "Driver location update failed");
    return body;
  },
};
