const express = require("express");
const { db, getNextTransportSeq, setNextTransportSeq } = require("../db");

const router = express.Router();

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

const DRIVER_POOL = [
  { name: "Ramesh Kumar", phone: "98765 43210" },
  { name: "Murugan S", phone: "98421 67890" },
  { name: "Suresh B", phone: "97910 24680" },
  { name: "Arun Prakash", phone: "99620 13579" },
  { name: "Kannan M", phone: "98840 11223" },
  { name: "Vijay Raj", phone: "97890 44556" },
  { name: "Dinesh Kumar", phone: "99520 77889" },
  { name: "Bala Murugan", phone: "98650 33445" },
  { name: "Prakash R", phone: "98410 66778" },
  { name: "Selvam A", phone: "97915 88990" },
];

const VEHICLE_PREFIX = {
  "Mini truck": "TN",
  "Tata Ace": "TN",
  "Tractor trolley": "TN",
  Lorry: "TN",
};

router.post("/transport/bookings", (req, res) => {
  const body = req.body || {};
  const farmer = clean(body.farmer);
  const phone = clean(body.phone);
  const state = clean(body.state);
  const areaVillage = clean(body.areaVillage);
  const vehicleType = clean(body.vehicleType);
  const pickupAddress = clean(body.pickupAddress);
  const dropAddress = clean(body.dropAddress);
  const produce = clean(body.produce);
  const qty = Number(body.qty);
  const pickupDate = clean(body.pickupDate);
  const pickupLat = body.pickupLat == null || body.pickupLat === "" ? null : Number(body.pickupLat);
  const pickupLng = body.pickupLng == null || body.pickupLng === "" ? null : Number(body.pickupLng);
  const dropLat = body.dropLat == null || body.dropLat === "" ? null : Number(body.dropLat);
  const dropLng = body.dropLng == null || body.dropLng === "" ? null : Number(body.dropLng);
  const voiceNote = body.voiceNote == null ? null : body.voiceNote;

  if (!farmer || !phone || !state || !areaVillage || !vehicleType || !pickupAddress || !dropAddress ||
      !produce || !Number.isInteger(qty) || qty < 1 || !pickupDate) {
    return res.status(400).json({ error: "Please fill all transport booking fields." });
  }

  const coordinates = [pickupLat, pickupLng, dropLat, dropLng];
  if (coordinates.some((value) => value !== null && !Number.isFinite(value))) {
    return res.status(400).json({ error: "Location coordinates must be valid numbers." });
  }
  if (voiceNote !== null && (typeof voiceNote !== "string" || voiceNote.length > 2_000_000)) {
    return res.status(400).json({ error: "Voice note is too large. Please record a shorter note." });
  }

  const seq = getNextTransportSeq();
  setNextTransportSeq(seq + 1);
  const bookingCode = `TR-${new Date().getFullYear()}-${String(seq).padStart(4, "0")}`;
  const driver = DRIVER_POOL[(seq - 1) % DRIVER_POOL.length];
  const vehiclePrefix = VEHICLE_PREFIX[vehicleType] || "TN";
  const vehicleNumber = `${vehiclePrefix} 45 ${String(3100 + seq).padStart(4, "0")}`;
  const vehicleToken = `VH-${new Date().getFullYear()}-${String(seq).padStart(4, "0")}`;
  const createdAt = Date.now();

  db.prepare(`INSERT INTO transport_bookings
    (bookingCode, farmer, phone, state, areaVillage, vehicleType, pickupAddress, pickupLat, pickupLng,
     dropAddress, dropLat, dropLng, produce, qty, pickupDate, driverName, driverPhone,
     vehicleNumber, vehicleToken, voiceNote, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'requested', ?)`)
    .run(
      bookingCode, farmer, phone, state, areaVillage, vehicleType, pickupAddress, pickupLat, pickupLng,
      dropAddress, dropLat, dropLng, produce, qty, pickupDate, driver.name, driver.phone,
      vehicleNumber, vehicleToken, voiceNote, createdAt,
    );

  res.status(201).json({
    bookingCode,
    status: "requested",
    farmer,
    phone,
    state,
    areaVillage,
    vehicleType,
    pickupAddress,
    pickupLat,
    pickupLng,
    dropAddress,
    dropLat,
    dropLng,
    produce,
    qty,
    pickupDate,
    driverName: driver.name,
    driverPhone: driver.phone,
    availableDrivers: DRIVER_POOL.map((availableDriver) => ({
      ...availableDriver,
      assigned: availableDriver.name === driver.name && availableDriver.phone === driver.phone,
    })),
    vehicleNumber,
    vehicleToken,
    voiceNote: voiceNote || null,
  });
});

router.get("/transport/bookings/:bookingCode", (req, res) => {
  const booking = db.prepare(
    "SELECT * FROM transport_bookings WHERE bookingCode = ?",
  ).get(req.params.bookingCode);
  if (!booking) return res.status(404).json({ error: "Transport booking not found." });
  res.json({
    ...booking,
    availableDrivers: DRIVER_POOL.map((availableDriver) => ({
      ...availableDriver,
      assigned: availableDriver.name === booking.driverName && availableDriver.phone === booking.driverPhone,
    })),
  });
});

function routeProgress(booking, lat, lng) {
  const startLat = Number(booking.pickupLat);
  const startLng = Number(booking.pickupLng);
  const endLat = Number(booking.dropLat);
  const endLng = Number(booking.dropLng);
  if (![startLat, startLng, endLat, endLng, lat, lng].every(Number.isFinite)) return null;

  const latSpan = endLat - startLat;
  const lngSpan = endLng - startLng;
  const denominator = (latSpan * latSpan) + (lngSpan * lngSpan);
  if (denominator === 0) return 0;
  return Math.max(0, Math.min(1,
    (((lat - startLat) * latSpan) + ((lng - startLng) * lngSpan)) / denominator,
  ));
}

/*
 * Driver GPS contract:
 * POST /api/transport/bookings/TR-2026-0001/location
 * { vehicleToken, lat, lng, accuracy }
 *
 * A future driver app can call this endpoint every few seconds. The farmer
 * tracking screen already polls the GET endpoint below, so no UI rewrite is
 * needed when real GPS starts flowing.
 */
router.post("/transport/bookings/:bookingCode/location", (req, res) => {
  const booking = db.prepare(
    "SELECT * FROM transport_bookings WHERE bookingCode = ?",
  ).get(req.params.bookingCode);
  if (!booking) return res.status(404).json({ error: "Transport booking not found." });

  const body = req.body || {};
  const suppliedToken = clean(body.vehicleToken || req.get("x-vehicle-token") || "");
  if (suppliedToken && suppliedToken !== booking.vehicleToken) {
    return res.status(403).json({ error: "Vehicle token does not match this booking." });
  }

  const lat = Number(body.lat);
  const lng = Number(body.lng);
  const accuracy = body.accuracy == null || body.accuracy === "" ? null : Number(body.accuracy);
  if (!Number.isFinite(lat) || lat < -90 || lat > 90 ||
      !Number.isFinite(lng) || lng < -180 || lng > 180) {
    return res.status(400).json({ error: "Valid latitude and longitude are required." });
  }
  if (accuracy !== null && (!Number.isFinite(accuracy) || accuracy < 0)) {
    return res.status(400).json({ error: "GPS accuracy must be a positive number." });
  }

  const gpsUpdatedAt = Date.now();
  db.prepare(`
    UPDATE transport_bookings
    SET currentLat = ?, currentLng = ?, gpsAccuracy = ?, gpsUpdatedAt = ?, status = 'on_the_way'
    WHERE bookingCode = ?
  `).run(lat, lng, accuracy, gpsUpdatedAt, booking.bookingCode);

  res.status(202).json({
    bookingCode: booking.bookingCode,
    vehicleToken: booking.vehicleToken,
    currentLat: lat,
    currentLng: lng,
    gpsAccuracy: accuracy,
    gpsUpdatedAt,
    locationSource: "driver_gps",
  });
});

// The feed prefers a recent driver GPS ping and falls back to a deterministic
// demo route until a driver app starts sending coordinates.
router.get("/transport/bookings/:bookingCode/tracking", (req, res) => {
  const booking = db.prepare(
    "SELECT * FROM transport_bookings WHERE bookingCode = ?",
  ).get(req.params.bookingCode);
  if (!booking) return res.status(404).json({ error: "Transport booking not found." });

  const hasRoute = [booking.pickupLat, booking.pickupLng, booking.dropLat, booking.dropLng]
    .every((value) => Number.isFinite(Number(value)));
  const hasGps = Number.isFinite(Number(booking.currentLat)) &&
    Number.isFinite(Number(booking.currentLng)) &&
    Number.isFinite(Number(booking.gpsUpdatedAt));
  const gpsAgeMs = hasGps ? Date.now() - Number(booking.gpsUpdatedAt) : Infinity;
  const gpsIsFresh = hasGps && gpsAgeMs <= 5 * 60_000;
  const elapsedMinutes = Math.max(0, (Date.now() - Number(booking.createdAt)) / 60_000);
  const simulatedProgress = Math.min(1, 0.12 + elapsedMinutes / 3);
  const gpsProgress = gpsIsFresh ? routeProgress(booking, Number(booking.currentLat), Number(booking.currentLng)) : null;
  const progress = gpsProgress == null ? simulatedProgress : gpsProgress;
  const status = progress >= 1 ? "complete" : progress >= 0.82 ? "arrived" : "on_the_way";
  const currentLat = gpsIsFresh
    ? Number(booking.currentLat)
    : hasRoute
      ? Number(booking.pickupLat) + (Number(booking.dropLat) - Number(booking.pickupLat)) * simulatedProgress
      : null;
  const currentLng = gpsIsFresh
    ? Number(booking.currentLng)
    : hasRoute
      ? Number(booking.pickupLng) + (Number(booking.dropLng) - Number(booking.pickupLng)) * simulatedProgress
      : null;

  res.json({
    bookingCode: booking.bookingCode,
    vehicleToken: booking.vehicleToken,
    driverName: booking.driverName,
    driverPhone: booking.driverPhone,
    vehicleNumber: booking.vehicleNumber,
    status,
    progress: Math.round(progress * 100),
    currentLat,
    currentLng,
    pickupLat: booking.pickupLat,
    pickupLng: booking.pickupLng,
    dropLat: booking.dropLat,
    dropLng: booking.dropLng,
    updatedAt: gpsIsFresh ? Number(booking.gpsUpdatedAt) : Date.now(),
    gpsAccuracy: gpsIsFresh ? Number(booking.gpsAccuracy) || null : null,
    locationSource: gpsIsFresh ? "driver_gps" : "demo_simulation",
    simulated: !gpsIsFresh,
  });
});

module.exports = router;