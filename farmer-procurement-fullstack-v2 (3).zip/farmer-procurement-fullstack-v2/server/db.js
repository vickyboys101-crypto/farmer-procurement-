/*
 * db.js — real SQLite database (Node's built-in node:sqlite module,
 * no native compilation needed). Replaces the old browser localStorage
 * "database" from the static prototype. Data survives server restarts
 * in kalam.db on disk.
 */
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const { CENTRES, SLOTS } = require("./data");

const DB_PATH = path.join(__dirname, "kalam.db");
const db = new DatabaseSync(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS bookings (
    token TEXT PRIMARY KEY,
    seq INTEGER NOT NULL,
    centreId TEXT NOT NULL,
    slotId TEXT NOT NULL,
    farmer TEXT NOT NULL,
    state TEXT,
    crop TEXT NOT NULL,
    qty INTEGER NOT NULL,
    village TEXT,
    areaVillage TEXT,
    locationLat REAL,
    locationLng REAL,
     voiceNote TEXT,
    status TEXT NOT NULL DEFAULT 'submitted',
    createdAt INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS transport_bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bookingCode TEXT NOT NULL UNIQUE,
    farmer TEXT NOT NULL,
    phone TEXT NOT NULL,
    state TEXT,
    areaVillage TEXT,
    vehicleType TEXT NOT NULL,
    pickupAddress TEXT NOT NULL,
    pickupLat REAL,
    pickupLng REAL,
    dropAddress TEXT NOT NULL,
    dropLat REAL,
    dropLng REAL,
    produce TEXT NOT NULL,
    qty INTEGER NOT NULL,
    pickupDate TEXT NOT NULL,
     voiceNote TEXT,
    status TEXT NOT NULL DEFAULT 'requested',
    createdAt INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
`);

// Keep databases created by an older copy of the app compatible with the
// improved location fields. SQLite does not support IF NOT EXISTS for columns.
for (const column of [
  "state TEXT",
  "village TEXT",
  "areaVillage TEXT",
  "locationLat REAL",
  "locationLng REAL",
  "voiceNote TEXT",
]) {
  try {
    db.exec(`ALTER TABLE bookings ADD COLUMN ${column}`);
  } catch {
    // The column already exists; this is expected on every later start.
  }
}

for (const column of ["state TEXT", "areaVillage TEXT", "voiceNote TEXT"]) {
  try {
    db.exec(`ALTER TABLE transport_bookings ADD COLUMN ${column}`);
  } catch {
    // The column already exists; this is expected on every later start.
  }
}

function getNextSeq() {
  const row = db.prepare("SELECT value FROM meta WHERE key = 'nextSeq'").get();
  if (row) return Number(row.value);
  db.prepare("INSERT INTO meta (key, value) VALUES ('nextSeq', '900')").run();
  return 900;
}

function setNextSeq(v) {
  db.prepare("INSERT INTO meta (key, value) VALUES ('nextSeq', ?) ON CONFLICT(key) DO UPDATE SET value = ?")
    .run(String(v), String(v));
}

function getNextTransportSeq() {
  const row = db.prepare("SELECT value FROM meta WHERE key = 'nextTransportSeq'").get();
  if (row) return Number(row.value);
  db.prepare("INSERT INTO meta (key, value) VALUES ('nextTransportSeq', '1')").run();
  return 1;
}

function setNextTransportSeq(v) {
  db.prepare("INSERT INTO meta (key, value) VALUES ('nextTransportSeq', ?) ON CONFLICT(key) DO UPDATE SET value = ?")
    .run(String(v), String(v));
}

// Seed a handful of "already booked" farmers on first run only, so the
// queue/admin views feel alive on first launch — same idea as the old
// prototype's seedBookings(), now persisted for real in SQLite.
function seedIfEmpty() {
  const count = db.prepare("SELECT COUNT(*) AS n FROM bookings").get().n;
  if (count > 0) return;

  const names = ["Selvi R", "Karthik M", "Lakshmi V", "Ravi Shankar", "Meena S", "Pandiyan K", "Devi N", "Arun Kumar"];
  const crops = ["Paddy", "Wheat", "Cotton", "Maize"];
  const statuses = ["submitted", "verified", "weighed", "paid"];
  let seq = 1;
  const insert = db.prepare(`INSERT INTO bookings (token, seq, centreId, slotId, farmer, crop, qty, status, createdAt)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

  // Only seed demo bookings for the hand-authored (named) centres, so a
  // fresh DB doesn't fill hundreds of auto-generated state centres with noise.
  const demoStates = new Set(["Tamil Nadu", "Punjab", "Uttar Pradesh", "Karnataka", "Maharashtra", "Andhra Pradesh"]);
  CENTRES.filter(c => demoStates.has(c.state)).forEach((centre) => {
    SLOTS.forEach((slot) => {
      const bookCount = Math.floor(Math.random() * (centre.capacityPerSlot * 0.6));
      for (let i = 0; i < bookCount; i++) {
        const status = statuses[Math.min(statuses.length - 1, Math.floor(Math.random() * statuses.length * 1.4))];
        const token = `${centre.id.toUpperCase()}-${slot.id.toUpperCase()}-${String(seq).padStart(3, "0")}`;
        insert.run(
          token, seq, centre.id, slot.id,
          names[Math.floor(Math.random() * names.length)],
          crops[Math.floor(Math.random() * crops.length)],
          10 + Math.floor(Math.random() * 40),
          status,
          Date.now() - Math.floor(Math.random() * 3600_000),
        );
        seq++;
      }
    });
  });
  setNextSeq(900);
}

seedIfEmpty();

module.exports = {
  db,
  getNextSeq,
  setNextSeq,
  getNextTransportSeq,
  setNextTransportSeq,
};
