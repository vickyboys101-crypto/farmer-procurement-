/*
 * predict.js (server-side)
 * Same heuristic as the original client-side prototype, now the
 * single source of truth on the backend. In production this function
 * is what a Prophet/scikit-learn microservice would replace — the
 * interface (centre + slot + queue -> predicted minutes) stays the same.
 */
const { SLOT_PRESSURE } = require("./data");

function waitMinutes(centre, slot, queueAhead) {
  const pressure = SLOT_PRESSURE[slot.id] || 1;
  const base = queueAhead * centre.serviceMinutes;
  const predicted = base * pressure;
  return Math.max(5, Math.round(predicted));
}

function callTime(waitMins) {
  const d = new Date(Date.now() + waitMins * 60_000);
  return d.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" });
}

module.exports = { waitMinutes, callTime };
