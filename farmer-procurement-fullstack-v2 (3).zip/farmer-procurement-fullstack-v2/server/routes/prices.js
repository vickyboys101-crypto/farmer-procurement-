/*
 * prices.js
 * Proxies the REAL public government dataset: "Variety-wise Daily
 * Market Prices Data of Commodity" (Agmarknet, via data.gov.in's
 * Open Government Data API). This is the one piece of genuinely live
 * government data available for this domain — there is no public
 * live "farmer queue length" dataset, so that part of the app stays
 * simulated (see README).
 *
 * Setup: get a free API key at https://data.gov.in/user (or the
 * shared demo key "579b464db66ec23bdd000001..." style keys shown on
 * the dataset page) and put it in server/.env as DATA_GOV_IN_API_KEY.
 * Dataset page: https://www.data.gov.in/resource/variety-wise-daily-market-prices-data-commodity
 */
const express = require("express");
const router = express.Router();

const RESOURCE_ID = "9ef84268-d588-465a-a308-a864a43d0070"; // Agmarknet daily mandi prices
const API_BASE = "https://api.data.gov.in/resource";

router.get("/prices", async (req, res) => {
  const apiKey = process.env.DATA_GOV_IN_API_KEY;
  if (!apiKey) {
    return res.status(501).json({
      error: "DATA_GOV_IN_API_KEY not set on the server.",
      hint: "Get a free key at https://data.gov.in/user, add it to server/.env, restart the server.",
    });
  }

  const { state, commodity, limit = 20 } = req.query;
  const params = new URLSearchParams({
    "api-key": apiKey,
    format: "json",
    limit: String(limit),
  });
  if (state) params.set("filters[state.keyword]", state);
  if (commodity) params.set("filters[commodity]", commodity);

  const url = `${API_BASE}/${RESOURCE_ID}?${params.toString()}`;

  try {
    const upstream = await fetch(url);
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: `data.gov.in returned ${upstream.status}` });
    }
    const data = await upstream.json();
    res.json({
      source: "data.gov.in — Agmarknet Variety-wise Daily Market Prices",
      records: data.records || [],
    });
  } catch (err) {
    res.status(502).json({ error: "Could not reach data.gov.in", detail: String(err) });
  }
});

module.exports = router;
