const express = require("express");

const router = express.Router();

router.get("/location/ip", async (req, res) => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch("https://ipapi.co/json/", {
      signal: controller.signal,
      headers: { "User-Agent": "Kalam-Farmer-Procurement/1.0" },
    });
    if (!response.ok) return res.status(502).json({ error: "Approximate location service is unavailable." });
    const data = await response.json();
    const lat = Number(data.latitude);
    const lng = Number(data.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return res.status(502).json({ error: "Approximate location was not available." });
    }
    res.json({
      lat,
      lng,
      village: data.city || data.region || "",
      district: data.city || "",
      state: data.region || "",
      displayName: [data.city, data.region, data.country_name].filter(Boolean).join(", "),
    });
  } catch (error) {
    res.status(502).json({
      error: error.name === "AbortError"
        ? "Approximate location lookup timed out."
        : "Could not find an approximate location.",
    });
  } finally {
    clearTimeout(timeout);
  }
});

// Nominatim gives village/town/district names without an API key. The request
// stays on the server so browsers do not hit CORS or rate-limit surprises.
router.get("/location/reverse", async (req, res) => {
  const lat = Number(req.query.lat);
  const lng = Number(req.query.lng);

  if (!Number.isFinite(lat) || !Number.isFinite(lng) ||
      lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    return res.status(400).json({ error: "Valid lat and lng query params are required." });
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const params = new URLSearchParams({
      lat: String(lat),
      lon: String(lng),
      format: "jsonv2",
      addressdetails: "1",
      "accept-language": "en",
    });
    const response = await fetch(`https://nominatim.openstreetmap.org/reverse?${params}`, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Kalam-Farmer-Procurement/1.0 (location lookup)",
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      return res.status(502).json({ error: "Location service is temporarily unavailable." });
    }

    const data = await response.json();
    const address = data.address || {};
    const village = address.village || address.hamlet || address.suburb ||
      address.town || address.city || address.municipality || "";
    const district = address.county || address.state_district || "";
    const state = address.state || "";

    res.json({
      village,
      district,
      state,
      displayName: data.display_name || [village, district, state].filter(Boolean).join(", "),
      lat,
      lng,
    });
  } catch (error) {
    res.status(502).json({
      error: error.name === "AbortError"
        ? "Location lookup timed out."
        : "Could not identify this location.",
    });
  } finally {
    clearTimeout(timeout);
  }
});

module.exports = router;