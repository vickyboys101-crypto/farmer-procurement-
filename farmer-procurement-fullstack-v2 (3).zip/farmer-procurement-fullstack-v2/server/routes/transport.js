const express = require("express");
const { db, getNextTransportSeq, setNextTransportSeq } = require("../db");

const router = express.Router();

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

router.post("/transport/bookings", (req, res) => {
  const body = req.body || {};
  const farmer = clean(body.farmer);
  const phone = clean(body.phone);
  const state = clean(body.state);
  const areaVillage = clean(body.areaVillage);
  const vehicleType = clean(body.vehicleType);
  const pickupAddress = clean(body.pickupAddress);
  const dropAddress = clean(body.dropAddress);
  const produce = clean(body.produce);
  const qty = Number(body.qty);
  const pickupDate = clean(body.pickupDate);
  const pickupLat = body.pickupLat == null || body.pickupLat === "" ? null : Number(body.pickupLat);
  const pickupLng = body.pickupLng == null || body.pickupLng === "" ? null : Number(body.pickupLng);
  const dropLat = body.dropLat == null || body.dropLat === "" ? null : Number(body.dropLat);
  const dropLng = body.dropLng == null || body.dropLng === "" ? null : Number(body.dropLng);
  const voiceNote = body.voiceNote == null ? null : body.voiceNote;

  if (!farmer || !phone || !state || !areaVillage || !vehicleType || !pickupAddress || !dropAddress ||
      !produce || !Number.isInteger(qty) || qty < 1 || !pickupDate) {
    return res.status(400).json({ error: "Please fill all transport booking fields." });
  }

  const coordinates = [pickupLat, pickupLng, dropLat, dropLng];
  if (coordinates.some((value) => value !== null && !Number.isFinite(value))) {
    return res.status(400).json({ error: "Location coordinates must be valid numbers." });
  }
  if (voiceNote !== null && (typeof voiceNote !== "string" || voiceNote.length > 2_000_000)) {
    return res.status(400).json({ error: "Voice note is too large. Please record a shorter note." });
  }

  const seq = getNextTransportSeq();
  setNextTransportSeq(seq + 1);
  const bookingCode = `TR-${new Date().getFullYear()}-${String(seq).padStart(4, "0")}`;

  db.prepare(`INSERT INTO transport_bookings
    (bookingCode, farmer, phone, state, areaVillage, vehicleType, pickupAddress, pickupLat, pickupLng,
     dropAddress, dropLat, dropLng, produce, qty, pickupDate, voiceNote, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'requested', ?)`)
    .run(
      bookingCode, farmer, phone, state, areaVillage, vehicleType, pickupAddress, pickupLat, pickupLng,
      dropAddress, dropLat, dropLng, produce, qty, pickupDate, voiceNote, Date.now(),
    );

  res.status(201).json({
    bookingCode,
    status: "requested",
    farmer,
    phone,
    state,
    areaVillage,
    vehicleType,
    pickupAddress,
    pickupLat,
    pickupLng,
    dropAddress,
    dropLat,
    dropLng,
    produce,
    qty,
    pickupDate,
    voiceNote: voiceNote || null,
  });
});

router.get("/transport/bookings/:bookingCode", (req, res) => {
  const booking = db.prepare(
    "SELECT * FROM transport_bookings WHERE bookingCode = ?",
  ).get(req.params.bookingCode);
  if (!booking) return res.status(404).json({ error: "Transport booking not found." });
  res.json(booking);
});

module.exports = router;