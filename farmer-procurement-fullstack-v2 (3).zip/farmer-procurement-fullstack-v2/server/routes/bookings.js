const express = require("express");
const { db, getNextSeq, setNextSeq } = require("../db");
const { CENTRES, SLOTS, STATES, STATE_CROPS, COMMON_CROPS, nearbyCentres } = require("../data");
const { waitMinutes, callTime } = require("../predict");

const router = express.Router();
const STATUS_ORDER = ["submitted", "verified", "weighed", "paid"];

function centreById(id) { return CENTRES.find(c => c.id === id); }
function slotById(id) { return SLOTS.find(s => s.id === id); }

function inQueueCount(centreId, slotId) {
  return db.prepare("SELECT COUNT(*) AS n FROM bookings WHERE centreId = ? AND slotId = ? AND status = 'submitted'")
    .get(centreId, slotId).n;
}

// -------------------------------------------------- Reference data
router.get("/states", (req, res) => res.json(STATES));
router.get("/slots", (req, res) => res.json(SLOTS));
router.get("/centres", (req, res) => res.json(CENTRES));

// -------------------------------------------------- Crops grown in a given state
router.get("/crops", (req, res) => {
  const { state } = req.query;
  if (state) {
    return res.json([...new Set([...(STATE_CROPS[state] || []), ...COMMON_CROPS])]);
  }
  res.json(STATE_CROPS); // full map, e.g. for admin/reporting use
});

// -------------------------------------------------- Centres near the farmer's GPS location
router.get("/centres/nearby", (req, res) => {
  const lat = Number(req.query.lat);
  const lng = Number(req.query.lng);
  const radiusKm = req.query.radius ? Number(req.query.radius) : 100;

  if (!Number.isFinite(lat) || !Number.isFinite(lng) ||
      lat < -90 || lat > 90 || lng < -180 || lng > 180 ||
      !Number.isFinite(radiusKm) || radiusKm <= 0 || radiusKm > 100) {
    return res.status(400).json({ error: "Valid lat, lng and radius (maximum 100 km) are required." });
  }
  res.json(nearbyCentres(lat, lng, radiusKm));
});

// -------------------------------------------------- Ranked options for a state (or an explicit centre-id list)
router.get("/rank", (req, res) => {
  const { state, centreIds } = req.query;
  let centres = CENTRES;
  if (centreIds) {
    const idSet = new Set(String(centreIds).split(",").filter(Boolean));
    centres = CENTRES.filter(c => idSet.has(c.id));
  } else if (state) {
    centres = CENTRES.filter(c => c.state === state);
  }
  const options = [];
  centres.forEach((centre) => {
    SLOTS.forEach((slot) => {
      const inQueue = inQueueCount(centre.id, slot.id);
      const capacity = centre.capacityPerSlot;
      options.push({
        centre, slot, inQueue, capacity,
        full: inQueue >= capacity,
        waitMins: waitMinutes(centre, slot, inQueue),
      });
    });
  });
  options.sort((a, b) => a.waitMins - b.waitMins);
  res.json(options);
});

// -------------------------------------------------- Create booking
router.post("/bookings", (req, res) => {
  const {
    centreId, slotId, farmer, state, areaVillage, village, crop, qty,
    locationLat, locationLng, voiceNote,
  } = req.body || {};
  const centre = centreById(centreId);
  const slot = slotById(slotId);
  if (!centre || !slot || !farmer || !state || !(areaVillage || village) || !crop || !qty) {
    return res.status(400).json({ error: "Missing or invalid booking fields." });
  }
  if (voiceNote != null && (typeof voiceNote !== "string" || voiceNote.length > 2_000_000)) {
    return res.status(400).json({ error: "Voice note is too large. Please record a shorter note." });
  }
  const seq = getNextSeq();
  setNextSeq(seq + 1);
  const token = `${centreId.toUpperCase()}-${slotId.toUpperCase()}-${String(seq).padStart(3, "0")}`;
  db.prepare(`INSERT INTO bookings
               (token, seq, centreId, slotId, farmer, state, crop, qty, village, areaVillage, locationLat, locationLng, voiceNote, status, createdAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted', ?)`)
    .run(
      token, seq, centreId, slotId, farmer, state, crop, Number(qty),
      areaVillage || village || null,
      areaVillage || village || null,
      locationLat == null ? null : Number(locationLat),
      locationLng == null ? null : Number(locationLng),
      voiceNote || null,
      Date.now(),
    );
  res.status(201).json({ token });
});

// -------------------------------------------------- Get one booking (with live wait info)
router.get("/bookings/:token", (req, res) => {
  const b = db.prepare("SELECT * FROM bookings WHERE token = ?").get(req.params.token);
  if (!b) return res.status(404).json({ error: "Booking not found." });
  const centre = centreById(b.centreId);
  const slot = slotById(b.slotId);
  const ahead = db.prepare(
    "SELECT COUNT(*) AS n FROM bookings WHERE centreId = ? AND slotId = ? AND seq < ? AND status = 'submitted'"
  ).get(b.centreId, b.slotId, b.seq).n;
  const waitMins = waitMinutes(centre, slot, ahead);
  res.json({
    token: b.token, status: b.status, name: b.farmer,
    state: b.state || centre.state, crop: b.crop, qty: b.qty,
    areaVillage: b.areaVillage || b.village || "",
    village: b.areaVillage || b.village || "",
    voiceNote: b.voiceNote || null,
    centreName: centre.name, slotLabel: slot.label,
    ahead, waitMins, callTime: callTime(waitMins),
  });
});

// -------------------------------------------------- Advance status (staff action)
router.post("/bookings/:token/advance", (req, res) => {
  const b = db.prepare("SELECT * FROM bookings WHERE token = ?").get(req.params.token);
  if (!b) return res.status(404).json({ error: "Booking not found." });
  const idx = STATUS_ORDER.indexOf(b.status);
  if (idx < STATUS_ORDER.length - 1) {
    const next = STATUS_ORDER[idx + 1];
    db.prepare("UPDATE bookings SET status = ? WHERE token = ?").run(next, b.token);
  }
  res.json({ ok: true });
});

// -------------------------------------------------- Admin: queue for one centre
router.get("/admin/centre/:centreId", (req, res) => {
  const centre = centreById(req.params.centreId);
  if (!centre) return res.status(404).json({ error: "Centre not found." });
  const bookings = db.prepare("SELECT * FROM bookings WHERE centreId = ? ORDER BY seq ASC").all(centre.id)
    .map(b => ({ ...b, slotLabel: slotById(b.slotId).label }));
  const totalCapacity = centre.capacityPerSlot * SLOTS.length;
  const totalBooked = bookings.length;
  res.json({ centre, bookings, totalCapacity, totalBooked });
});

module.exports = router;
