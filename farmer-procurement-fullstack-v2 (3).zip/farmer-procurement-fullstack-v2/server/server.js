require("dotenv").config();
const path = require("node:path");
const express = require("express");

const bookingsRouter = require("./routes/bookings");
const pricesRouter = require("./routes/prices");
const locationRouter = require("./routes/location");
const transportRouter = require("./routes/transport");

const app = express();
const PORT = process.env.PORT || 3000;

// Voice notes are sent as short base64 audio data URLs from the browser.
app.use(express.json({ limit: "3mb" }));
app.use("/api", bookingsRouter);
app.use("/api", pricesRouter);
app.use("/api", locationRouter);
app.use("/api", transportRouter);
app.use(express.static(path.join(__dirname, "..", "public")));

app.listen(PORT, () => {
  console.log(`Kalam server running: http://localhost:${PORT}`);
});
