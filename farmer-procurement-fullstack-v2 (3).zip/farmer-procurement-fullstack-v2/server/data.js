/*
 * data.js — static reference data (states, slots, centres).
 * This is the single source of truth the database is seeded from.
 */

const STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa",
  "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala",
  "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland",
  "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
  "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi (NCT)", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry",
];

const SLOTS = [
  { id: "s1", label: "9:00 AM - 11:00 AM" },
  { id: "s2", label: "11:00 AM - 1:00 PM" },
  { id: "s3", label: "1:00 PM - 3:00 PM" },
  { id: "s4", label: "3:00 PM - 5:00 PM" },
];

const NAMED_CENTRES = [
  { id: "c1", state: "Tamil Nadu", name: "Ariyalur PACCS Procurement Centre", capacityPerSlot: 18, serviceMinutes: 6, lat: 11.1401, lng: 79.0782 },
  { id: "c2", state: "Tamil Nadu", name: "Thanjavur Regulated Market", capacityPerSlot: 26, serviceMinutes: 5, lat: 10.7870, lng: 79.1378 },
  { id: "c3", state: "Tamil Nadu", name: "Kumbakonam Direct Purchase Centre", capacityPerSlot: 14, serviceMinutes: 7, lat: 10.9602, lng: 79.3845 },
  { id: "c4", state: "Tamil Nadu", name: "Papanasam Godown Yard", capacityPerSlot: 20, serviceMinutes: 6, lat: 10.9167, lng: 79.2667 },
  { id: "c5", state: "Punjab", name: "Ludhiana Mandi Procurement Centre", capacityPerSlot: 30, serviceMinutes: 5, lat: 30.9010, lng: 75.8573 },
  { id: "c6", state: "Punjab", name: "Patiala Regulated Market", capacityPerSlot: 22, serviceMinutes: 6, lat: 30.3398, lng: 76.3869 },
  { id: "c7", state: "Uttar Pradesh", name: "Meerut Godown Yard", capacityPerSlot: 24, serviceMinutes: 6, lat: 28.9845, lng: 77.7064 },
  { id: "c8", state: "Uttar Pradesh", name: "Varanasi Direct Purchase Centre", capacityPerSlot: 16, serviceMinutes: 7, lat: 25.3176, lng: 82.9739 },
  { id: "c9", state: "Karnataka", name: "Mysuru Regulated Market", capacityPerSlot: 20, serviceMinutes: 6, lat: 12.2958, lng: 76.6394 },
  { id: "c10", state: "Karnataka", name: "Hubballi PACCS Procurement Centre", capacityPerSlot: 18, serviceMinutes: 6, lat: 15.3647, lng: 75.1240 },
  { id: "c11", state: "Maharashtra", name: "Nashik Direct Purchase Centre", capacityPerSlot: 25, serviceMinutes: 5, lat: 19.9975, lng: 73.7898 },
  { id: "c12", state: "Maharashtra", name: "Pune Godown Yard", capacityPerSlot: 28, serviceMinutes: 5, lat: 18.5204, lng: 73.8567 },
  { id: "c13", state: "Andhra Pradesh", name: "Guntur Regulated Market", capacityPerSlot: 22, serviceMinutes: 6, lat: 16.3067, lng: 80.4365 },
  { id: "c14", state: "Andhra Pradesh", name: "Vijayawada PACCS Procurement Centre", capacityPerSlot: 19, serviceMinutes: 6, lat: 16.5062, lng: 80.6480 },
];

/*
 * TOWN_DATA — real district/agri towns spread across every state and UT,
 * with approximate real-world coordinates. This is what "Use my location"
 * (100 km radius search) actually needs: a centre roughly every 60-120 km,
 * not just one cluster next to the state capital. Towns already covered by
 * NAMED_CENTRES above are skipped here to avoid duplicates.
 */
const TOWN_DATA = {
  "Andhra Pradesh": [["Kurnool", 15.8281, 78.0373], ["Nellore", 14.4426, 79.9865], ["Kadapa", 14.4673, 78.8242], ["Anantapur", 14.6819, 77.6006], ["Tirupati", 13.6288, 79.4192], ["Chittoor", 13.2172, 79.1003], ["Kakinada", 16.9891, 82.2475], ["Rajahmundry", 17.0005, 81.804], ["Eluru", 16.7107, 81.0952], ["Ongole", 15.5057, 80.0499], ["Srikakulam", 18.2949, 83.8938], ["Vizianagaram", 18.1067, 83.3956], ["Visakhapatnam", 17.6868, 83.2185], ["Machilipatnam", 16.1875, 81.1389], ["Proddatur", 14.7502, 78.5481], ["Adoni", 15.628, 77.2749], ["Hindupur", 13.8285, 77.4913]],
  "Arunachal Pradesh": [["Itanagar", 27.0844, 93.6053], ["Naharlagun", 27.1044, 93.6953], ["Pasighat", 28.0667, 95.3167], ["Ziro", 27.55, 93.8333], ["Tezu", 27.9167, 96.1667], ["Bomdila", 27.2645, 92.4159], ["Seppa", 27.2667, 93.0667], ["Koloriang", 27.9333, 93.3667], ["Daporijo", 27.9833, 94.2167], ["Aalo", 28.1667, 94.8], ["Yingkiong", 28.6333, 95.0333], ["Roing", 28.1333, 95.8333], ["Anini", 28.7833, 95.9167], ["Hawai", 28.0667, 96.9833], ["Namsai", 27.6167, 95.7], ["Changlang", 27.13, 95.69], ["Khonsa", 27.0167, 95.5833], ["Longding", 27.0, 95.3667]],
  "Assam": [["Guwahati", 26.1445, 91.7362], ["Jorhat", 26.7509, 94.2037], ["Nagaon", 26.3475, 92.684], ["Dibrugarh", 27.4728, 94.912], ["Silchar", 24.8333, 92.7789], ["Tezpur", 26.6338, 92.8], ["Bongaigaon", 26.4769, 90.5583], ["Karimganj", 24.8697, 92.3558], ["Goalpara", 26.1653, 90.6265], ["Barpeta", 26.3223, 91.006], ["Tinsukia", 27.4922, 95.3548], ["Diphu", 25.8433, 93.4292], ["Nalbari", 26.446, 91.439], ["Sivasagar", 26.985, 94.638], ["Golaghat", 26.51, 93.97], ["Hailakandi", 24.684, 92.563], ["Kokrajhar", 26.401, 90.272], ["Dhubri", 26.02, 89.98], ["Morigaon", 26.25, 92.34], ["Darrang", 26.45, 92.03], ["Lakhimpur", 27.24, 94.11], ["Dhemaji", 27.48, 94.58], ["Hojai", 26.0, 92.85], ["Charaideo", 27.0, 95.0]],
  "Bihar": [["Patna", 25.5941, 85.1376], ["Gaya", 24.7955, 85.0002], ["Muzaffarpur", 26.1225, 85.3906], ["Bhagalpur", 25.2445, 86.9718], ["Darbhanga", 26.1542, 85.8918], ["Purnia", 25.7771, 87.4753], ["Ara", 25.5541, 84.6614], ["Begusarai", 25.4182, 86.1272], ["Katihar", 25.5394, 87.5872], ["Chapra", 25.7815, 84.7479], ["Munger", 25.3746, 86.4735], ["Motihari", 26.6469, 84.9161], ["Bettiah", 26.802, 84.501], ["Sasaram", 24.95, 84.0167], ["Siwan", 26.2189, 84.3563], ["Samastipur", 25.856, 85.7856], ["Nalanda", 25.198, 85.514], ["Nawada", 24.885, 85.547], ["Jamui", 24.926, 86.226], ["Banka", 24.885, 86.92], ["Khagaria", 25.502, 86.47], ["Madhepura", 25.92, 86.79], ["Saharsa", 25.88, 86.6], ["Supaul", 26.12, 86.6], ["Kishanganj", 26.105, 87.945], ["Araria", 26.15, 87.52], ["Sitamarhi", 26.59, 85.49], ["Sheohar", 26.515, 85.29], ["Vaishali", 25.69, 85.21], ["Gopalganj", 26.47, 84.43], ["Buxar", 25.565, 83.977], ["Jehanabad", 25.213, 84.988], ["Arwal", 25.25, 84.68], ["Aurangabad", 24.75, 84.37], ["Kaimur", 25.03, 83.61], ["Lakhisarai", 25.17, 86.09], ["Sheikhpura", 25.137, 85.85]],
  "Chhattisgarh": [["Raipur", 21.2514, 81.6296], ["Bilaspur", 22.0797, 82.1409], ["Durg", 21.1904, 81.2849], ["Raigarh", 21.8974, 83.395], ["Korba", 22.3595, 82.6819], ["Jagdalpur", 19.0748, 82.0232], ["Ambikapur", 23.12, 83.201], ["Rajnandgaon", 21.0974, 81.03], ["Dhamtari", 20.7072, 81.5497], ["Mahasamund", 21.1094, 82.0989], ["Kanker", 20.27, 81.49], ["Kawardha", 22.01, 81.24], ["Janjgir", 22.0, 82.57], ["Jashpur", 22.89, 84.14], ["Koriya", 23.25, 82.57], ["Surajpur", 23.22, 82.87], ["Balrampur", 23.61, 83.61], ["Bemetara", 21.71, 81.53], ["Balod", 20.73, 81.2], ["Bijapur", 18.79, 80.73], ["Dantewada", 18.9, 81.35], ["Kondagaon", 19.59, 81.66], ["Narayanpur", 19.71, 81.25], ["Sukma", 18.39, 81.66], ["Gariaband", 20.63, 82.06], ["Mungeli", 22.07, 81.68], ["Baloda Bazar", 21.66, 82.16], ["Surguja", 23.12, 83.2], ["Gaurela-Pendra-Marwahi", 22.75, 81.9]],
  "Goa": [["Panaji", 15.4909, 73.8278], ["Margao", 15.2832, 73.9862]],
  "Gujarat": [["Ahmedabad", 23.0225, 72.5714], ["Rajkot", 22.3039, 70.8022], ["Surat", 21.1702, 72.8311], ["Bhavnagar", 21.7645, 72.1519], ["Vadodara", 22.3072, 73.1812], ["Jamnagar", 22.4707, 70.0577], ["Junagadh", 21.5222, 70.4579], ["Gandhinagar", 23.2156, 72.6369], ["Anand", 22.5645, 72.9289], ["Bharuch", 21.7051, 72.9959], ["Mehsana", 23.588, 72.3693], ["Navsari", 20.9463, 72.927], ["Porbandar", 21.6417, 69.6293], ["Morbi", 22.8173, 70.8377], ["Patan", 23.8493, 72.1266], ["Godhra", 22.7788, 73.6143], ["Amreli", 21.6032, 71.221], ["Modasa", 23.4644, 73.2996], ["Palanpur", 24.1747, 72.4384], ["Botad", 22.1704, 71.6683], ["Chhota Udaipur", 22.3053, 74.0146], ["Dahod", 22.836, 74.2593], ["Khambhalia", 22.2394, 68.9678], ["Veraval", 20.9159, 70.3629], ["Nadiad", 22.6939, 72.8615], ["Bhuj", 23.242, 69.6669], ["Lunawada", 23.123, 73.6206], ["Rajpipla", 21.8825, 73.5], ["Himmatnagar", 23.5992, 72.9611], ["Surendranagar", 22.7469, 71.6479], ["Vyara", 21.1167, 73.4], ["Valsad", 20.5992, 72.9342], ["Dang-Ahwa", 20.75, 73.69]],
  "Haryana": [["Karnal", 29.6857, 76.9905], ["Kurukshetra", 29.9695, 76.8783], ["Sirsa", 29.5321, 75.0318], ["Panipat", 29.3909, 76.9635], ["Hisar", 29.1492, 75.7217], ["Rohtak", 28.8955, 76.6066], ["Ambala", 30.3782, 76.7767], ["Yamunanagar", 30.129, 77.2674], ["Bhiwani", 28.7975, 76.1322], ["Rewari", 28.199, 76.6173], ["Faridabad", 28.4089, 77.3178], ["Gurugram", 28.4595, 77.0266], ["Jind", 29.316, 76.314], ["Fatehabad", 29.5152, 75.4535], ["Sonipat", 28.9931, 77.0151], ["Panchkula", 30.6942, 76.8606], ["Jhajjar", 28.61, 76.66], ["Mahendragarh", 28.28, 76.15], ["Palwal", 28.143, 77.326], ["Kaithal", 29.8, 76.4], ["Nuh", 28.11, 77.0], ["Charkhi Dadri", 28.59, 76.27]],
  "Himachal Pradesh": [["Shimla", 31.1048, 77.1734], ["Mandi", 31.708, 76.9318], ["Solan", 30.9045, 77.0967], ["Kangra", 32.0998, 76.2691], ["Una", 31.4685, 76.2708], ["Bilaspur", 31.332, 76.758], ["Hamirpur", 31.6861, 76.5217], ["Chamba", 32.5556, 76.1263], ["Kullu", 31.9576, 77.1095], ["Nahan", 30.559, 77.293], ["Keylong", 32.57, 77.03], ["Kinnaur (Reckong Peo)", 31.55, 78.26]],
  "Jharkhand": [["Ranchi", 23.3441, 85.3096], ["Jamshedpur", 22.8046, 86.2029], ["Dhanbad", 23.7957, 86.4304], ["Hazaribagh", 23.9925, 85.3617], ["Bokaro", 23.6693, 86.1511], ["Deoghar", 24.4823, 86.6961], ["Giridih", 24.1913, 86.305], ["Dumka", 24.2676, 87.2497], ["Daltonganj", 24.0432, 84.0731], ["Chaibasa", 22.554, 85.809], ["Gumla", 23.05, 84.53], ["Lohardaga", 23.43, 84.68], ["Simdega", 22.62, 84.51], ["Khunti", 23.07, 85.28], ["Saraikela", 22.7, 86.0], ["Jamtara", 23.96, 86.81], ["Godda", 24.83, 87.21], ["Sahibganj", 25.25, 87.64], ["Pakur", 24.63, 87.85], ["Koderma", 24.47, 85.59], ["Chatra", 24.21, 84.87], ["Latehar", 23.75, 84.5], ["Garhwa", 24.16, 83.8], ["Ramgarh", 23.63, 85.52]],
  "Karnataka": [["Belagavi", 15.8497, 74.4977], ["Davangere", 14.4644, 75.9218], ["Raichur", 16.2076, 77.3463], ["Mandya", 12.5242, 76.8958], ["Bengaluru", 12.9716, 77.5946], ["Ballari", 15.1394, 76.9214], ["Bidar", 17.9104, 77.5199], ["Vijayapura", 16.8302, 75.71], ["Chikkamagaluru", 13.3161, 75.772], ["Kalaburagi", 17.3297, 76.8343], ["Shivamogga", 13.9299, 75.5681], ["Tumkur", 13.3379, 77.1173], ["Udupi", 13.3409, 74.7421], ["Chitradurga", 14.2251, 76.398], ["Kolar", 13.1362, 78.1298], ["Bagalkot", 16.1691, 75.6615], ["Bengaluru Rural", 13.2434, 77.7159], ["Chamarajanagar", 11.9236, 76.9456], ["Chikkaballapur", 13.4355, 77.7315], ["Mangaluru", 12.9141, 74.856], ["Dharwad", 15.4589, 75.0078], ["Gadag", 15.4297, 75.6295], ["Hassan", 13.0072, 76.1004], ["Haveri", 14.7936, 75.4044], ["Madikeri", 12.4244, 75.7382], ["Koppal", 15.3547, 76.1547], ["Karwar", 14.8022, 74.129], ["Ramanagara", 12.7159, 77.2822], ["Hosapete", 15.2694, 76.3961], ["Yadgir", 16.769, 77.1376]],
  "Kerala": [["Thiruvananthapuram", 8.5241, 76.9366], ["Kochi", 9.9312, 76.2673], ["Kozhikode", 11.2588, 75.7804], ["Palakkad", 10.7867, 76.6548], ["Thrissur", 10.5276, 76.2144], ["Kollam", 8.8932, 76.6141], ["Alappuzha", 9.4981, 76.3388], ["Kottayam", 9.5916, 76.5222], ["Painavu", 9.8492, 76.9744], ["Malappuram", 11.051, 76.0711], ["Kannur", 11.8745, 75.3704], ["Kasaragod", 12.4996, 74.9869], ["Kalpetta", 11.6854, 76.0819], ["Pathanamthitta", 9.2648, 76.787]],
  "Madhya Pradesh": [["Bhopal", 23.2599, 77.4126], ["Indore", 22.7196, 75.8577], ["Jabalpur", 23.1815, 79.9864], ["Gwalior", 26.2183, 78.1828], ["Ujjain", 23.1793, 75.7849], ["Sagar", 23.8388, 78.7378], ["Rewa", 24.5364, 81.3037], ["Satna", 24.6005, 80.8322], ["Ratlam", 23.3315, 75.0367], ["Chhindwara", 22.0574, 78.9382], ["Khandwa", 21.8258, 76.3529], ["Dewas", 22.9676, 76.0534], ["Vidisha", 23.5251, 77.8081], ["Shivpuri", 25.4243, 77.66], ["Mandsaur", 24.073, 75.07], ["Narmadapuram", 22.75, 77.71], ["Damoh", 23.833, 79.442], ["Agar Malwa", 23.7128, 76.0157], ["Alirajpur", 22.3155, 74.36], ["Anuppur", 23.105, 81.69], ["Ashoknagar", 24.575, 77.73], ["Balaghat", 21.8083, 80.1833], ["Barwani", 22.0333, 74.9], ["Betul", 21.9022, 77.9], ["Bhind", 26.5644, 78.7873], ["Burhanpur", 21.3, 76.2333], ["Chhatarpur", 24.918, 79.588], ["Dhar", 22.6, 75.3], ["Dindori", 22.942, 81.077], ["Guna", 24.6467, 77.3111], ["Harda", 22.345, 77.094], ["Jhabua", 22.766, 74.59], ["Katni", 23.834, 80.395], ["Khargone", 21.8235, 75.61], ["Mandla", 22.6, 80.38], ["Morena", 26.5, 78.0], ["Narsinghpur", 22.95, 79.2], ["Neemuch", 24.47, 74.87], ["Niwari", 25.01, 78.95], ["Panna", 24.718, 80.181], ["Raisen", 23.33, 77.8], ["Rajgarh", 24.007, 76.729], ["Sehore", 23.202, 77.085], ["Seoni", 22.087, 79.545], ["Shahdol", 23.3, 81.35], ["Sheopur", 25.666, 76.7], ["Sidhi", 24.42, 81.88], ["Singrauli", 24.199, 82.675], ["Tikamgarh", 24.744, 78.833], ["Umaria", 23.53, 80.84]],
  "Maharashtra": [["Nagpur", 21.1458, 79.0882], ["Chhatrapati Sambhajinagar", 19.8762, 75.3433], ["Kolhapur", 16.705, 74.2433], ["Amravati", 20.9374, 77.7796], ["Mumbai", 19.076, 72.8777], ["Thane", 19.2183, 72.9781], ["Solapur", 17.6599, 75.9064], ["Satara", 17.6805, 74.0183], ["Sangli", 16.8524, 74.5815], ["Ahmednagar", 19.0948, 74.748], ["Latur", 18.4088, 76.5604], ["Akola", 20.7002, 77.0082], ["Jalgaon", 21.0077, 75.5626], ["Nanded", 19.1383, 77.321], ["Wardha", 20.7453, 78.6022], ["Yavatmal", 20.3888, 78.1204], ["Ratnagiri", 16.9902, 73.312], ["Beed", 18.9891, 75.7601], ["Bhandara", 21.1704, 79.6533], ["Buldhana", 20.5293, 76.181], ["Chandrapur", 19.9615, 79.2961], ["Dhule", 20.9042, 74.7749], ["Gadchiroli", 20.1809, 80.0038], ["Gondia", 21.4602, 80.1922], ["Hingoli", 19.7146, 77.1489], ["Jalna", 19.841, 75.8864], ["Nandurbar", 21.3667, 74.2333], ["Dharashiv", 18.1861, 76.0419], ["Palghar", 19.6969, 72.7699], ["Parbhani", 19.2704, 76.7601], ["Alibag", 18.6414, 72.8722], ["Sindhudurg", 16.1667, 73.6833], ["Washim", 20.1114, 77.1339]],
  "Manipur": [["Imphal", 24.817, 93.9368], ["Thoubal", 24.6333, 93.9833], ["Churachandpur", 24.3333, 93.6833], ["Ukhrul", 25.05, 94.3667], ["Bishnupur", 24.63, 93.75], ["Senapati", 25.27, 94.02], ["Tamenglong", 24.98, 93.5], ["Chandel", 24.33, 94.02], ["Jiribam", 24.81, 93.12], ["Kangpokpi", 25.13, 93.98], ["Kakching", 24.49, 93.99], ["Tengnoupal", 24.33, 94.25], ["Pherzawl", 24.3, 93.38], ["Noney", 24.83, 93.52], ["Kamjong", 25.25, 94.49]],
  "Meghalaya": [["Shillong", 25.5788, 91.8933], ["Tura", 25.5138, 90.2032], ["Jowai", 25.45, 92.1935], ["Nongstoin", 25.5167, 91.2667], ["Williamnagar", 25.51, 90.63], ["Baghmara", 25.2, 90.63], ["Nongpoh", 25.9, 91.88], ["Resubelpara", 25.63, 90.63], ["Mairang", 25.55, 91.63], ["Ampati", 25.45, 90.15], ["Khliehriat", 25.35, 92.33]],
  "Mizoram": [["Aizawl", 23.7271, 92.7176], ["Lunglei", 22.8874, 92.7357], ["Champhai", 23.4667, 93.3333], ["Serchhip", 23.3, 92.85], ["Kolasib", 24.22, 92.68], ["Lawngtlai", 22.53, 92.89], ["Mamit", 23.93, 92.5], ["Saiha", 22.49, 92.97]],
  "Nagaland": [["Kohima", 25.6751, 94.1086], ["Dimapur", 25.9091, 93.7267], ["Mokokchung", 26.3333, 94.5167], ["Wokha", 26.1, 94.2667], ["Tuensang", 26.2667, 94.8333], ["Mon", 26.75, 95.07], ["Zunheboto", 26.0, 94.51], ["Phek", 25.66, 94.48], ["Kiphire", 25.83, 94.79], ["Longleng", 26.51, 94.95], ["Peren", 25.51, 93.74]],
  "Odisha": [["Bhubaneswar", 20.2961, 85.8245], ["Cuttack", 20.4625, 85.883], ["Sambalpur", 21.4669, 83.9756], ["Berhampur", 19.3149, 84.7941], ["Rourkela", 22.2604, 84.8536], ["Puri", 19.8135, 85.8312], ["Balasore", 21.4942, 86.9317], ["Bhadrak", 21.0574, 86.515], ["Angul", 20.84, 85.1017], ["Koraput", 18.812, 82.7108], ["Bolangir", 20.71, 83.49], ["Jharsuguda", 21.856, 84.006], ["Baripada", 21.93, 86.73], ["Bargarh", 21.33, 83.62], ["Boudh", 20.83, 84.33], ["Deogarh", 21.53, 84.73], ["Dhenkanal", 20.66, 85.6], ["Gajapati (Paralakhemundi)", 18.78, 84.08], ["Ganjam", 19.39, 85.05], ["Jagatsinghpur", 20.26, 86.17], ["Jajpur", 20.85, 86.33], ["Kalahandi (Bhawanipatna)", 19.91, 83.16], ["Kandhamal (Phulbani)", 20.47, 84.23], ["Kendrapara", 20.5, 86.42], ["Kendujhar", 21.63, 85.58], ["Malkangiri", 18.35, 81.9], ["Nabarangpur", 19.23, 82.55], ["Nayagarh", 20.13, 85.1], ["Nuapada", 20.81, 82.55], ["Rayagada", 19.17, 83.42], ["Sonepur (Subarnapur)", 20.83, 83.9], ["Sundargarh", 22.12, 84.03]],
  "Punjab": [["Amritsar", 31.634, 74.8723], ["Bathinda", 30.211, 74.9455], ["Jalandhar", 31.326, 75.5762], ["Mohali", 30.7046, 76.7179], ["Firozpur", 30.9331, 74.6225], ["Moga", 30.8158, 75.1711], ["Hoshiarpur", 31.53, 75.9145], ["Sangrur", 30.2458, 75.8421], ["Pathankot", 32.2746, 75.6521], ["Faridkot", 30.6742, 74.755], ["Kapurthala", 31.38, 75.38], ["Gurdaspur", 32.04, 75.4], ["Tarn Taran", 31.45, 74.93], ["Fazilka", 30.4, 74.03], ["Muktsar", 30.47, 74.52], ["Barnala", 30.38, 75.55], ["Mansa", 29.99, 75.4], ["Rupnagar", 30.97, 76.53], ["Fatehgarh Sahib", 30.64, 76.4], ["Malerkotla", 30.53, 75.88], ["Nawanshahr", 31.12, 76.12], ],
  "Rajasthan": [["Jaipur", 26.9124, 75.7873], ["Jodhpur", 26.2389, 73.0243], ["Kota", 25.2138, 75.8648], ["Bikaner", 28.0229, 73.3119], ["Udaipur", 24.5854, 73.7125], ["Ajmer", 26.4499, 74.6399], ["Alwar", 27.553, 76.6346], ["Bharatpur", 27.2152, 77.4909], ["Sikar", 27.6094, 75.1399], ["Bhilwara", 25.3407, 74.6313], ["Pali", 25.7711, 73.3234], ["Ganganagar", 29.9094, 73.88], ["Churu", 28.3, 74.9667], ["Barmer", 25.7521, 71.3961], ["Jaisalmer", 26.9157, 70.9083], ["Nagaur", 27.2, 73.7333], ["Sawai Madhopur", 26.0173, 76.352], ["Banswara", 23.5461, 74.4416], ["Baran", 25.1013, 76.5136], ["Chittorgarh", 24.8887, 74.6269], ["Dausa", 26.8925, 76.335], ["Dholpur", 26.7017, 77.893], ["Dungarpur", 23.8431, 73.7147], ["Hanumangarh", 29.5822, 74.3297], ["Jalore", 25.3462, 72.6162], ["Jhalawar", 24.5966, 76.161], ["Jhunjhunu", 28.13, 75.4], ["Karauli", 26.4988, 77.0227], ["Pratapgarh", 24.0322, 74.7799], ["Rajsamand", 25.07, 73.88], ["Sirohi", 24.885, 72.859], ["Tonk", 26.166, 75.79]],
  "Sikkim": [["Gangtok", 27.3389, 88.6065], ["Namchi", 27.1667, 88.3667], ["Geyzing", 27.2833, 88.2333], ["Mangan", 27.5083, 88.5333]],
  "Tamil Nadu": [["Tiruchirappalli", 10.7905, 78.7047], ["Madurai", 9.9252, 78.1198], ["Coimbatore", 11.0168, 76.9558], ["Salem", 11.6643, 78.146], ["Erode", 11.341, 77.7172], ["Chennai", 13.0827, 80.2707], ["Vellore", 12.9165, 79.1325], ["Tirunelveli", 8.7139, 77.7567], ["Thoothukudi", 8.7642, 78.1348], ["Dindigul", 10.3624, 77.9695], ["Cuddalore", 11.748, 79.7714], ["Kanchipuram", 12.8342, 79.7036], ["Namakkal", 11.2189, 78.1677], ["Karur", 10.9601, 78.0766], ["Sivaganga", 9.8433, 78.4809], ["Virudhunagar", 9.5851, 77.9581], ["Nagapattinam", 10.7672, 79.8449], ["Krishnagiri", 12.5186, 78.2137], ["Theni", 10.0104, 77.4768], ["Ramanathapuram", 9.3639, 78.8395], ["Chengalpattu", 12.6819, 79.9888], ["Dharmapuri", 12.1277, 78.158], ["Kallakurichi", 11.7381, 78.9582], ["Kanyakumari", 8.178, 77.4106], ["Mayiladuthurai", 11.1041, 79.6549], ["Udhagamandalam", 11.4102, 76.695], ["Perambalur", 11.2342, 78.8807], ["Pudukkottai", 10.3813, 78.8214], ["Ranipet", 12.9249, 79.3308], ["Tenkasi", 8.9603, 77.3152], ["Tirupathur", 12.495, 78.5678], ["Tiruppur", 11.1085, 77.3411], ["Tiruvallur", 13.1231, 79.912], ["Tiruvannamalai", 12.2253, 79.0747], ["Tiruvarur", 10.7661, 79.6345], ["Viluppuram", 11.9401, 79.4861]],
  "Telangana": [["Hyderabad", 17.385, 78.4867], ["Warangal", 17.9689, 79.5941], ["Nizamabad", 18.6725, 78.0941], ["Karimnagar", 18.4386, 79.1288], ["Khammam", 17.2473, 80.1514], ["Nalgonda", 17.0575, 79.269], ["Mahbubnagar", 16.7488, 77.9855], ["Adilabad", 19.6641, 78.532], ["Suryapet", 17.14, 79.62], ["Siddipet", 18.1018, 78.852], ["Kothagudem", 17.5504, 80.6183], ["Jagtial", 18.7909, 78.9119], ["Jangaon", 17.7255, 79.1546], ["Bhupalpally", 18.4321, 79.8963], ["Gadwal", 16.2311, 77.8063], ["Kamareddy", 18.322, 78.341], ["Asifabad", 19.3667, 79.2833], ["Mahabubabad", 17.5983, 80.0022], ["Mancherial", 18.872, 79.464], ["Medak", 18.046, 78.27], ["Malkajgiri", 17.6238, 78.4738], ["Mulugu", 18.19, 80.01], ["Nagarkurnool", 16.4837, 78.3238], ["Narayanpet", 16.744, 77.495], ["Nirmal", 19.0968, 78.3444], ["Peddapalli", 18.6152, 79.3728], ["Sircilla", 18.3894, 78.8144], ["Rangareddy", 17.356, 78.475], ["Sangareddy", 17.6248, 78.0898], ["Vikarabad", 17.3378, 77.9046], ["Wanaparthy", 16.3628, 78.0625], ["Bhuvanagiri", 17.5622, 78.8931]],
  "Tripura": [["Agartala", 23.8315, 91.2868], ["Udaipur (Tripura)", 23.5333, 91.4833], ["Dharmanagar", 24.3667, 92.1667], ["Kailashahar", 24.33, 92.01], ["Ambassa", 23.95, 91.85], ["Belonia", 23.25, 91.45], ["Khowai", 24.07, 91.6], ["Sabroom", 23.0, 91.73]],
  "Uttar Pradesh": [["Lucknow", 26.8467, 80.9462], ["Kanpur", 26.4499, 80.3319], ["Agra", 27.1767, 78.0081], ["Gorakhpur", 26.7606, 83.3732], ["Prayagraj", 25.4358, 81.8463], ["Bareilly", 28.367, 79.4304], ["Aligarh", 27.8974, 78.088], ["Moradabad", 28.8386, 78.7733], ["Saharanpur", 29.968, 77.5451], ["Jhansi", 25.4484, 78.5685], ["Ghaziabad", 28.6692, 77.4538], ["Firozabad", 27.1592, 78.3957], ["Mathura", 27.4924, 77.6737], ["Muzaffarnagar", 29.4727, 77.7085], ["Rae Bareli", 26.2309, 81.2338], ["Sitapur", 27.568, 80.682], ["Azamgarh", 26.068, 83.183], ["Ballia", 25.76, 84.15], ["Ayodhya", 26.7924, 82.1993], ["Basti", 26.8148, 82.7274], ["Etawah", 26.7855, 79.0154], ["Banda", 25.4762, 80.3355], ["Amethi", 26.1536, 81.8154], ["Amroha", 28.9044, 78.4672], ["Auraiya", 26.4649, 79.5136], ["Badaun", 28.0362, 79.1204], ["Baghpat", 28.9448, 77.2183], ["Bahraich", 27.5742, 81.5967], ["Balrampur", 27.4304, 82.1857], ["Barabanki", 26.9269, 81.1897], ["Bhadohi", 25.3939, 82.5686], ["Bijnor", 29.373, 78.133], ["Bulandshahr", 28.4041, 77.8498], ["Chandauli", 25.26, 83.2649], ["Chitrakoot", 25.2005, 80.8574], ["Deoria", 26.5024, 83.7791], ["Etah", 27.559, 78.664], ["Farrukhabad", 27.3927, 79.581], ["Fatehpur", 25.9298, 80.8134], ["Noida", 28.5355, 77.391], ["Ghazipur", 25.5847, 83.5773], ["Gonda", 27.133, 81.964], ["Hamirpur", 25.9556, 80.15], ["Hapur", 28.73, 77.78], ["Hardoi", 27.3958, 80.131], ["Hathras", 27.5959, 78.053], ["Jalaun", 26.149, 79.339], ["Jaunpur", 25.7479, 82.6837], ["Kannauj", 27.0524, 79.9159], ["Kanpur Dehat", 26.478, 80.047], ["Kasganj", 27.8106, 78.644], ["Kaushambi", 25.535, 81.377], ["Kushinagar", 26.7415, 83.889], ["Lakhimpur Kheri", 27.9483, 80.7826], ["Lalitpur", 24.6879, 78.413], ["Maharajganj", 27.144, 83.561], ["Mahoba", 25.2925, 79.872], ["Mainpuri", 27.235, 79.027], ["Mau", 25.9417, 83.561], ["Mirzapur", 25.146, 82.569], ["Pilibhit", 28.632, 79.806], ["Pratapgarh", 25.907, 81.999], ["Rampur", 28.801, 79.025], ["Sambhal", 28.586, 78.572], ["Sant Kabir Nagar", 26.766, 83.033], ["Shahjahanpur", 27.883, 79.91], ["Shamli", 29.45, 77.31], ["Shravasti", 27.514, 82.027], ["Siddharthnagar", 27.274, 83.018], ["Sonbhadra", 24.69, 83.063], ["Sultanpur", 26.2648, 82.073], ["Unnao", 26.5464, 80.4879], ],
  "Uttarakhand": [["Dehradun", 30.3165, 78.0322], ["Haridwar", 29.9457, 78.1642], ["Haldwani", 29.2183, 79.513], ["Nainital", 29.3803, 79.4636], ["Rudrapur", 28.97, 79.4], ["Roorkee", 29.8543, 77.888], ["Almora", 29.5892, 79.6467], ["Pithoragarh", 29.5828, 80.2181], ["Bageshwar", 29.84, 79.77], ["Champawat", 29.33, 80.09], ["Chamoli (Gopeshwar)", 30.39, 79.34], ["Pauri", 30.15, 78.78], ["Rudraprayag", 30.28, 78.98], ["Tehri", 30.38, 78.48], ["Uttarkashi", 30.73, 78.44]],
  "West Bengal": [["Kolkata", 22.5726, 88.3639], ["Bardhaman", 23.2324, 87.8615], ["Malda", 25.0108, 88.1411], ["Siliguri", 26.7271, 88.3953], ["Asansol", 23.6739, 86.9524], ["Durgapur", 23.5204, 87.3119], ["Kharagpur", 22.346, 87.232], ["Howrah", 22.5958, 88.2636], ["Krishnanagar", 23.4058, 88.5023], ["Berhampore", 24.1, 88.25], ["Jalpaiguri", 26.545, 88.7194], ["Cooch Behar", 26.3452, 89.4482], ["Purulia", 23.332, 86.365], ["Bankura", 23.2324, 87.07], ["Midnapore", 22.4257, 87.32], ["Alipurduar", 26.49, 89.53], ["Jhargram", 22.45, 86.98], ["Kalimpong", 27.06, 88.47], ["Basirhat", 22.66, 88.86], ["Diamond Harbour", 22.19, 88.19], ["Ranaghat", 23.18, 88.56]],
  "Andaman and Nicobar Islands": [["Port Blair", 11.6234, 92.7265], ["Diglipur", 13.25, 92.9667], ["Mayabunder", 12.9333, 92.9167], ["Car Nicobar", 9.15, 92.75]],
  "Chandigarh": [["Chandigarh", 30.7333, 76.7794]],
  "Dadra and Nagar Haveli and Daman and Diu": [["Silvassa", 20.2738, 73.0169], ["Daman", 20.3974, 72.8328], ["Diu", 20.7144, 70.9874]],
  "Delhi (NCT)": [["New Delhi", 28.7041, 77.1025], ["Najafgarh", 28.6092, 76.9797], ["Rohini", 28.7495, 77.0565], ["Dwarka", 28.5921, 77.046], ["Shahdara", 28.67, 77.29], ["North East Delhi", 28.68, 77.27], ["South East Delhi", 28.55, 77.26], ["West Delhi", 28.66, 77.09]],
  "Jammu and Kashmir": [["Srinagar", 34.0837, 74.7973], ["Jammu", 32.7266, 74.857], ["Anantnag", 33.7311, 75.1487], ["Baramulla", 34.209, 74.3436], ["Udhampur", 32.916, 75.142], ["Kathua", 32.3701, 75.517], ["Pulwama", 33.871, 74.893], ["Kupwara", 34.526, 74.254], ["Budgam", 33.998, 74.718], ["Bandipora", 34.42, 74.65], ["Ganderbal", 34.23, 74.77], ["Shopian", 33.718, 74.833], ["Kulgam", 33.644, 75.017], ["Rajouri", 33.37, 74.31], ["Poonch", 33.77, 74.09], ["Doda", 33.15, 75.55], ["Ramban", 33.24, 75.24], ["Kishtwar", 33.31, 75.77], ["Samba", 32.57, 75.12], ["Reasi", 33.08, 74.83]],
  "Ladakh": [["Leh", 34.1526, 77.5771], ["Kargil", 34.5539, 76.1349]],
  "Lakshadweep": [["Kavaratti", 10.5593, 72.6358], ["Agatti", 10.85, 72.1833]],
  "Puducherry": [["Puducherry", 11.9416, 79.8083], ["Karaikal", 10.9254, 79.838], ["Mahe", 11.705, 75.537], ["Yanam", 16.7333, 82.2167]],
};

// Cycled across towns so generated centres don't all read the same way.
const NAME_TEMPLATES = [
  (t) => `${t} Regulated Market`,
  (t) => `${t} PACCS Procurement Centre`,
  (t) => `${t} Direct Purchase Centre`,
  (t) => `${t} Godown Yard`,
  (t) => `${t} Mandi Procurement Centre`,
];

let genId = 100;
const GENERATED_CENTRES = [];
Object.entries(TOWN_DATA).forEach(([state, towns]) => {
  towns.forEach(([town, lat, lng], i) => {
    GENERATED_CENTRES.push({
      id: `g${genId++}`,
      state,
      name: NAME_TEMPLATES[i % NAME_TEMPLATES.length](town),
      capacityPerSlot: 14 + ((genId + i) % 4) * 4,   // varies 14-26, deterministic
      serviceMinutes: 5 + ((genId + i) % 3),          // varies 5-7
      lat, lng,
    });
  });
});

const CENTRES = [...NAMED_CENTRES, ...GENERATED_CENTRES];

/** Great-circle distance between two lat/lng points, in kilometres. */
function distanceKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Centres within `radiusKm` of (lat, lng), nearest first, de-duplicated by id.
 * The radius is strict: an out-of-range centre is never presented as nearby.
 */
function nearbyCentres(lat, lng, radiusKm = 100) {
  const seen = new Set();
  const withDistance = CENTRES
    .filter(c => !seen.has(c.id) && seen.add(c.id))
    .map(c => ({ ...c, distanceKm: Math.round(distanceKm(lat, lng, c.lat, c.lng) * 10) / 10 }))
    .sort((a, b) => a.distanceKm - b.distanceKm);

  return {
    radiusUsed: radiusKm,
    centres: withDistance.filter(c => c.distanceKm <= radiusKm),
  };
}

// Time-of-day crowd multiplier — mid-morning and early afternoon run busier.
const SLOT_PRESSURE = { s1: 1.15, s2: 1.35, s3: 1.2, s4: 0.85 };

/*
 * STATE_CROPS — major crops actually procured/harvested state-wise.
 * Used to filter the "Crop" dropdown once a farmer picks their state,
 * instead of showing the same fixed 4 crops nationwide.
 */
const STATE_CROPS = {
  "Andhra Pradesh": ["Paddy", "Cotton", "Groundnut", "Chillies", "Maize", "Sugarcane", "Tobacco", "Turmeric", "Red Gram", "Black Gram"],
  "Arunachal Pradesh": ["Paddy", "Maize", "Millet", "Ginger", "Mustard", "Pulses", "Buckwheat", "Orange"],
  "Assam": ["Paddy", "Jute", "Tea", "Rapeseed & Mustard", "Maize", "Sugarcane", "Potato", "Lentil", "Sesame"],
  "Bihar": ["Paddy", "Wheat", "Maize", "Jute", "Sugarcane", "Lentil", "Gram", "Potato", "Mustard", "Oilseeds"],
  "Chhattisgarh": ["Paddy", "Maize", "Groundnut", "Kodo Millet", "Wheat", "Gram", "Pulses", "Soybean", "Sugarcane"],
  "Goa": ["Paddy", "Coconut", "Cashew", "Sugarcane", "Arecanut", "Banana", "Mango", "Vegetables"],
  "Gujarat": ["Cotton", "Groundnut", "Wheat", "Bajra", "Castor", "Sugarcane", "Cumin", "Sesame", "Tobacco", "Banana"],
  "Haryana": ["Wheat", "Paddy", "Cotton", "Mustard", "Sugarcane", "Bajra", "Maize", "Gram", "Barley", "Sunflower"],
  "Himachal Pradesh": ["Wheat", "Maize", "Apple", "Barley", "Potato", "Peas", "Tomato", "Ginger", "Cherry"],
  "Jharkhand": ["Paddy", "Maize", "Wheat", "Pulses", "Oilseeds", "Vegetables", "Lac", "Sugarcane"],
  "Karnataka": ["Paddy", "Maize", "Ragi", "Cotton", "Sugarcane", "Coffee", "Tur", "Groundnut", "Jowar", "Arecanut"],
  "Kerala": ["Paddy", "Coconut", "Rubber", "Pepper", "Banana", "Cardamom", "Ginger", "Tapioca", "Cashew"],
  "Madhya Pradesh": ["Wheat", "Soybean", "Paddy", "Gram", "Cotton", "Maize", "Lentil", "Mustard", "Garlic", "Onion"],
  "Maharashtra": ["Cotton", "Soybean", "Sugarcane", "Jowar", "Paddy", "Onion", "Tur", "Gram", "Groundnut", "Grapes"],
  "Manipur": ["Paddy", "Maize", "Pulses", "Oilseeds", "Potato", "Mustard", "Ginger", "Turmeric", "Vegetables"],
  "Meghalaya": ["Paddy", "Maize", "Turmeric", "Ginger", "Pineapple", "Potato", "Black Pepper", "Arecanut"],
  "Mizoram": ["Paddy", "Maize", "Ginger", "Turmeric", "Chilli", "Sesame", "Pineapple", "Banana"],
  "Nagaland": ["Paddy", "Maize", "Millet", "Pulses", "Soybean", "Potato", "Ginger", "Pineapple"],
  "Odisha": ["Paddy", "Groundnut", "Jute", "Turmeric", "Maize", "Sugarcane", "Mung Bean", "Sesame", "Mustard"],
  "Punjab": ["Wheat", "Paddy", "Cotton", "Maize", "Sugarcane", "Mustard", "Potato", "Barley", "Sunflower", "Groundnut"],
  "Rajasthan": ["Bajra", "Wheat", "Mustard", "Gram", "Cotton", "Guar", "Barley", "Cumin", "Sesame", "Moth Bean"],
  "Sikkim": ["Maize", "Paddy", "Ginger", "Cardamom", "Buckwheat", "Turmeric", "Orange", "Vegetables"],
  "Tamil Nadu": ["Paddy", "Sugarcane", "Cotton", "Groundnut", "Maize", "Banana", "Coconut", "Tapioca", "Turmeric", "Sesame", "Black Gram"],
  "Telangana": ["Paddy", "Cotton", "Maize", "Chillies", "Turmeric", "Soybean", "Red Gram", "Green Gram", "Groundnut", "Sesame"],
  "Tripura": ["Paddy", "Jute", "Rubber", "Tea", "Pineapple", "Bamboo", "Potato", "Ginger"],
  "Uttar Pradesh": ["Wheat", "Paddy", "Sugarcane", "Potato", "Maize", "Mustard", "Gram", "Lentil", "Mango", "Peas"],
  "Uttarakhand": ["Wheat", "Paddy", "Sugarcane", "Maize", "Mandua", "Barley", "Potato", "Apple", "Rajma"],
  "West Bengal": ["Paddy", "Jute", "Potato", "Tea", "Mustard", "Wheat", "Maize", "Sugarcane", "Sesame", "Mango"],
  "Andaman and Nicobar Islands": ["Paddy", "Coconut", "Arecanut", "Banana", "Pineapple", "Cashew"],
  "Chandigarh": ["Wheat", "Paddy", "Vegetables", "Maize", "Mustard", "Potato"],
  "Dadra and Nagar Haveli and Daman and Diu": ["Paddy", "Sugarcane", "Vegetables", "Mango", "Banana", "Coconut"],
  "Delhi (NCT)": ["Wheat", "Paddy", "Vegetables", "Maize", "Mustard", "Potato"],
  "Jammu and Kashmir": ["Paddy", "Maize", "Apple", "Saffron", "Wheat", "Walnut", "Almond", "Cherry"],
  "Ladakh": ["Barley", "Wheat", "Apricot", "Peas", "Potato", "Buckwheat"],
  "Lakshadweep": ["Coconut", "Banana", "Tuna", "Vegetables"],
  "Puducherry": ["Paddy", "Sugarcane", "Groundnut", "Cashew", "Banana", "Vegetables"],
};

// These additional options cover common local produce that farmers may bring
// even when it is not one of the state's largest commodities. They are merged
// with the state list by the API and used by both farmer and transport forms.
const COMMON_CROPS = [
  "Tomato", "Onion", "Chilli", "Brinjal", "Okra", "Cabbage", "Cauliflower",
  "Carrot", "Beans", "Green Gram", "Red Gram", "Black Gram", "Sunflower",
  "Millets", "Ragi", "Turmeric", "Ginger", "Garlic", "Coriander", "Other",
];

module.exports = {
  STATES, SLOTS, CENTRES, SLOT_PRESSURE, STATE_CROPS, COMMON_CROPS,
  nearbyCentres, distanceKm,
};
