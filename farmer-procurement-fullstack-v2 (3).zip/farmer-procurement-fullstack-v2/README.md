# Kalam — Smart Procurement (full-stack version)

Upgraded from the static HTML prototype to a real client-server app:

- **Backend:** Node.js + Express + SQLite (Node's built-in `node:sqlite`, no native
  build tools needed). Bookings, queue counts and wait-time prediction all live on
  the server now — not in browser localStorage. Data survives restarts
  (`server/kalam.db`).
- **Frontend:** same UI, now talks to the backend over a REST API (`/api/...`)
  instead of reading/writing localStorage directly.
- **Live location:** the browser GPS is used directly (fresh high-accuracy reading,
  no cached location) and reverse-geocoded only for the readable village / area label.
  Procurement centres are strictly filtered to a **100 km radius**; a farther centre
  is never shown as nearby. The UI also shows the GPS coordinates and accuracy.
- **Transport booking:** a separate transport tab supports vehicle requests with
  separate farmer name, state, area / village, vehicle type, produce / load,
  quantity, independent pickup and delivery addresses, live location for both
  points, pickup date, voice notes and a booking number. The confirmation token
  repeats the exact produce / load and quantity selected during booking.
- **Separate booking details:** farmer and transport records store name, state
  and area / village as individual fields. The voice note remains optional and
  separate from those fields.
- **More crop choices:** the state-wise crop dropdown includes the original
  state crops plus common produce such as tomato, onion, chilli, brinjal, okra,
  vegetables, pulses, millets, turmeric, ginger, garlic, coriander and Other.
- **Per-field voice input:** the shared/common voice-note box has been removed.
  Each field has its own microphone button: farmer name, state, crop, quantity,
  area / village, plus every transport field (name, phone, state, area / village,
  vehicle, produce / load, quantity, pickup, delivery and date). Voice input uses
  the browser Speech Recognition API and fills only the field beside the button.
- **Location recovery:** live location tries accurate GPS, then network/Wi-Fi
  location, then an approximate server-side IP location fallback. Reverse
  geocoding still fills the area / village and state when available.
- **Real government data:** a working proxy to `data.gov.in`'s Agmarknet
  "Variety-wise Daily Market Prices" dataset (`GET /api/prices?state=...&commodity=...`).
  This is genuine live government data, once you add a free API key.

## What is still simulated, and why

There is **no public, live government dataset for farmer procurement-centre queue
length or wait times.** No state Agriculture Marketing Department or FCI exposes
that as an open, real-time API. So the queue counts / wait-time prediction stay
**simulated** (server-computed, same heuristic as before) — this isn't a shortcut,
it's because that data genuinely doesn't exist publicly. If your college/organisation
gets a data-sharing agreement with a real APMC/PACCS system, swap the queries in
`server/routes/bookings.js` for real ones — the rest of the app doesn't need to change.

## Setup

```bash
cd server
npm install
cp .env.example .env        # then paste your data.gov.in API key into .env
npm start
```

Open **http://localhost:3000** — that's it, frontend and backend are served from
the same Express app.

Get a free `data.gov.in` API key: register at https://data.gov.in/user, then
"My Account → API Keys". Paste it into `server/.env` as `DATA_GOV_IN_API_KEY`.
Without a key, everything works except `/api/prices`, which returns a clear
501 error telling you the key is missing.

## Project layout

```
server/
  server.js          Express app entry point
  db.js              SQLite setup + seed data
  data.js            States / slots / centres reference data
  predict.js          Wait-time heuristic (server-side now)
  routes/bookings.js  Booking + ranking + admin API
  routes/location.js  GPS reverse-geocoding proxy
  routes/transport.js Vehicle booking API
  routes/prices.js    Live data.gov.in mandi price proxy
  package.json
  .env.example
public/
  index.html
  css/styles.css
  js/store.js         Frontend API client (was localStorage before)
  js/app.js           UI logic
  js/i18n.js           12-language dictionary + state → language map
```

## API quick reference

| Method | Path                              | What it does                          |
|--------|------------------------------------|----------------------------------------|
| GET    | /api/states                       | All 28 states + 8 UTs                  |
| GET    | /api/slots                        | Time slots                             |
| GET    | /api/centres                      | All procurement centres                |
| GET    | /api/crops?state=X                 | Expanded crop / produce options       |
| GET    | /api/rank?state=X                 | Ranked centre/slot options by wait     |
| POST   | /api/bookings                     | Create a booking, returns `{ token }`  |
| GET    | /api/bookings/:token               | Booking + live wait/ahead info         |
| POST   | /api/bookings/:token/advance       | Advance status (staff action)          |
| GET    | /api/admin/centre/:centreId        | Queue + capacity for one centre        |
| GET    | /api/prices?state=&commodity=      | Live data.gov.in mandi prices          |
| GET    | /api/location/reverse?lat=&lng=    | Village / area from browser GPS       |
| GET    | /api/location/ip                   | Approximate fallback location          |
| POST   | /api/transport/bookings            | Create a vehicle transport request    |
| GET    | /api/transport/bookings/:code      | Read a transport request              |

## Location and microphone permissions

Use the app through `http://localhost:3000`, not by double-clicking
`public/index.html`. Browser GPS and microphone permissions are required for
live-location and per-field voice buttons. In a deployed copy, use HTTPS;
browsers block GPS/microphone access on insecure public pages. If permission is
denied, the app tries approximate IP location and the address fields remain
editable.
