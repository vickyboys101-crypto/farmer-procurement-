/* app.js — wires the UI to the real backend (Store -> /api/*). */

(async function () {
  try {
    await Store.init(); // load states/slots/centres from the server once
  } catch (err) {
    // Most common cause: index.html was opened directly (file://) instead
    // of through the Node server, so /api/* calls have nowhere to go.
    document.getElementById("screen-entry").innerHTML = `
      <div style="padding:24px;background:#fff3f2;border:1px solid #f3b4ae;border-radius:10px;max-width:640px;">
        <strong>Can't reach the backend server.</strong>
        <p style="margin:8px 0 0;">
          This page must be opened through the Node server, not by double-clicking index.html.<br><br>
          In a terminal: <code>cd server</code> → <code>npm install</code> → <code>npm start</code>,
          then open <code>http://localhost:3000</code> in the browser (not a file:// path).
        </p>
      </div>`;
    console.error(err);
    return;
  }

  let currentBookingToken = null;
  let tokenPollTimer = null;
  let currentFarmerDetails = null;

  // ---------------------------------------------------------------- Nav
  const navButtons = document.querySelectorAll(".navbtn");
  const viewFarmer = document.getElementById("view-farmer");
  const viewTransport = document.getElementById("view-transport");
  const viewAdmin = document.getElementById("view-admin");

  navButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      navButtons.forEach(b => b.setAttribute("aria-selected", "false"));
      btn.setAttribute("aria-selected", "true");
      const view = btn.dataset.view;
      viewFarmer.hidden = view !== "farmer";
      viewTransport.hidden = view !== "transport";
      viewAdmin.hidden = view !== "admin";
      if (view === "admin") renderAdmin();
    });
  });

  // ---------------------------------------------------------------- Farmer: screens
  const screens = {
    entry: document.getElementById("screen-entry"),
    slots: document.getElementById("screen-slots"),
    token: document.getElementById("screen-token"),
  };
  function showScreen(name) {
    Object.entries(screens).forEach(([key, el]) => { el.hidden = key !== name; });
  }
  document.querySelectorAll("[data-back]").forEach((el) => {
    el.addEventListener("click", () => showScreen(el.dataset.back));
  });

  // ---------------------------------------------------------------- State dropdown
  const stateSelect = document.getElementById("f-state");
  const transportStateSelect = document.getElementById("t-state");
  Store.states.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s; opt.textContent = s;
    stateSelect.appendChild(opt);
    transportStateSelect.appendChild(opt.cloneNode(true));
  });

  // ------------------------------------------------ Crop dropdown (state-wise)
  const cropSelect = document.getElementById("f-crop");
  async function refreshCropsForState(state) {
    cropSelect.innerHTML = "";
    if (!state) return;
    let crops = [];
    try {
      crops = await Store.cropsByState(state);
    } catch (err) {
      console.error("Failed to load crops for state", state, err);
    }
    if (!crops.length) {
      // Fallback so the form never shows an empty crop list.
      crops = ["Paddy", "Wheat", "Cotton", "Maize"];
    }
    crops.forEach((crop) => {
      const opt = document.createElement("option");
      opt.value = crop; opt.textContent = crop;
      cropSelect.appendChild(opt);
    });
  }
  stateSelect.addEventListener("change", () => refreshCropsForState(stateSelect.value));

  // Transport uses the same state-wise crop list. This keeps Produce / load
  // structured instead of relying on one combined comment/free-text value.
  const transportProduceSelect = document.getElementById("t-produce");
  async function refreshTransportProduceForState(state) {
    transportProduceSelect.innerHTML = "";
    if (!state) {
      transportProduceSelect.innerHTML = '<option value="" disabled selected>Select your state first</option>';
      return;
    }
    let crops = [];
    try {
      crops = await Store.cropsByState(state);
    } catch (err) {
      console.error("Failed to load transport produce list", state, err);
    }
    if (!crops.length) crops = ["Paddy", "Wheat", "Cotton", "Maize", "Other"];
    crops.forEach((crop) => {
      const opt = document.createElement("option");
      opt.value = crop;
      opt.textContent = crop;
      transportProduceSelect.appendChild(opt);
    });
  }
  transportStateSelect.addEventListener("change", () => {
    refreshTransportProduceForState(transportStateSelect.value);
  });

  // ------------------------------------------------ "Use my location" -> nearby centres
  let nearMeCentreIds = null;   // when set, renderSlots ranks only these centres
  let nearMeRadiusUsed = null;
  let nearMeDistances = {};     // centreId -> distanceKm, captured at search time
  let farmerLocationCoords = { lat: null, lng: null };
  let farmerLocationAccuracy = null;
  let settingStateProgrammatically = false;

  const locBtn = document.getElementById("btn-use-location");
  const locStatus = document.getElementById("location-status");

  function getBrowserPosition(options) {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation is not supported by this browser."));
        return;
      }
      navigator.geolocation.getCurrentPosition(resolve, reject, options);
    });
  }

  async function getPositionWithFallback() {
    try {
      // First attempt: accurate GPS. Second attempt: faster network/Wi-Fi
      // location, which works on more phones when GPS is indoors.
      return { position: await getBrowserPosition({
        enableHighAccuracy: true, timeout: 12000, maximumAge: 30000,
      }), source: "GPS" };
    } catch (firstError) {
      try {
        return { position: await getBrowserPosition({
          enableHighAccuracy: false, timeout: 10000, maximumAge: 300000,
        }), source: "network location" };
      } catch (secondError) {
        // IP fallback is approximate, but still gives the farmer a usable
        // nearby-centre starting point when browser permission is blocked.
        const place = await Store.ipLocation();
        return {
          position: {
            coords: { latitude: place.lat, longitude: place.lng, accuracy: null },
          },
          source: "approximate IP location",
          fallbackPlace: place,
        };
      }
    }
  }

  function findMatchingState(stateName) {
    const wanted = normalizeSpeech(stateName);
    return Store.states.find((state) => {
      const available = normalizeSpeech(state);
      return available === wanted || available.includes(wanted) || wanted.includes(available);
    }) || "";
  }

  async function applyPlaceToFarmerForm(place) {
    const villageInput = document.getElementById("f-area-village");
    villageInput.value = place.village || place.district || place.displayName || "";
    const matchedState = findMatchingState(place.state);
    if (matchedState) {
      settingStateProgrammatically = true;
      stateSelect.value = matchedState;
      settingStateProgrammatically = false;
      await refreshCropsForState(matchedState);
    }
  }

  locBtn.addEventListener("click", async () => {
    locBtn.disabled = true;
    locStatus.textContent = "Finding your live location…";
    try {
      const { position, source, fallbackPlace } = await getPositionWithFallback();
      const { latitude, longitude, accuracy } = position.coords;
      farmerLocationCoords = { lat: latitude, lng: longitude };
      farmerLocationAccuracy = Number.isFinite(accuracy) ? accuracy : null;
      const SEARCH_RADIUS_KM = 100;
      const [nearbyResult, locationResult] = await Promise.allSettled([
        Store.centresNearby(latitude, longitude, SEARCH_RADIUS_KM),
        Store.reverseGeocode(latitude, longitude),
      ]);
      const { radiusUsed, centres } = nearbyResult.status === "fulfilled"
        ? nearbyResult.value
        : { radiusUsed: null, centres: [] };
      const detectedPlace = locationResult.status === "fulfilled"
        ? locationResult.value
        : (fallbackPlace || {});
      if (detectedPlace.village || detectedPlace.state || detectedPlace.displayName) {
        await applyPlaceToFarmerForm(detectedPlace);
      }
      nearMeCentreIds = centres.map((centre) => centre.id);
      nearMeRadiusUsed = radiusUsed;
      nearMeDistances = Object.fromEntries(centres.map((centre) => [centre.id, centre.distanceKm]));
      const place = locationResult.status === "fulfilled" ? locationResult.value : (fallbackPlace || {});
      const label = place.village || place.district || "coordinates detected";
      const accuracyText = farmerLocationAccuracy != null
        ? ` · ±${Math.round(farmerLocationAccuracy)} m`
        : "";
      if (centres.length) {
        locStatus.textContent = `${source}: ${label}${accuracyText}. Found ${centres.length} centre(s) within ${SEARCH_RADIUS_KM} km.`;
      } else {
        nearMeCentreIds = null;
        locStatus.textContent = `${source}: ${label}${accuracyText}. No centre within ${SEARCH_RADIUS_KM} km; choose your state to continue.`;
      }
    } catch (error) {
      console.error("Location failed", error);
      locStatus.textContent = "Location could not be detected. Allow location access, or enter area/village manually.";
    } finally {
      locBtn.disabled = false;
    }
  });

  // Manually changing the state after a location search means the farmer
  // wants that state's full list again, not the "near me" shortlist.
  stateSelect.addEventListener("change", () => {
    if (!settingStateProgrammatically) {
      nearMeCentreIds = null;
      nearMeDistances = {};
      locStatus.textContent = "";
    }
  });

  // ---------------------------------------------------------------- Language dropdown + i18n
  const languageSelect = document.getElementById("f-language");
  Object.entries(LANGUAGES).forEach(([code, label]) => {
    const opt = document.createElement("option");
    opt.value = code; opt.textContent = label;
    languageSelect.appendChild(opt);
  });

  function applyLanguage(lang) {
    const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      if (dict[key]) el.textContent = dict[key];
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.dataset.i18nPlaceholder;
      if (dict[key]) el.placeholder = dict[key];
    });
    languageSelect.value = lang;
  }
  languageSelect.addEventListener("change", () => applyLanguage(languageSelect.value));
  stateSelect.addEventListener("change", () => {
    const lang = STATE_LANGUAGE[stateSelect.value];
    if (lang) applyLanguage(lang);
  });
  applyLanguage("en");

  // ------------------------------------------------ Per-field voice input
  // Each microphone button owns one field. Nothing is collected into a
  // shared/common voice note.
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let activeRecognition = null;
  let activeVoiceButton = null;

  function speechLanguage() {
    const language = languageSelect.value || "en";
    return {
      en: "en-IN", hi: "hi-IN", ta: "ta-IN", te: "te-IN", kn: "kn-IN",
      ml: "ml-IN", mr: "mr-IN", gu: "gu-IN", pa: "pa-IN", bn: "bn-IN",
      or: "or-IN", as: "as-IN", ur: "ur-IN",
    }[language] || "en-IN";
  }

  function normalizeSpeech(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/[.,/#!$%^&*;:{}=_`~()]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function setSpokenValue(target, transcript, mode) {
    const spoken = transcript.trim();
    if (!spoken) return false;

    if (mode === "select" || target.tagName === "SELECT") {
      const normalizedSpoken = normalizeSpeech(spoken);
      const options = [...target.options].filter(option => !option.disabled && option.value);
      const match = options
        .map(option => ({ option, text: normalizeSpeech(option.textContent), value: normalizeSpeech(option.value) }))
        .sort((a, b) => Math.max(b.text.length, b.value.length) - Math.max(a.text.length, a.value.length))
        .find(item => normalizedSpoken === item.text || normalizedSpoken === item.value ||
          normalizedSpoken.includes(item.text) || item.text.includes(normalizedSpoken));
      if (!match) return false;
      target.value = match.option.value;
    } else if (mode === "number" || mode === "phone") {
      const digitWords = {
        zero: "0", one: "1", two: "2", three: "3", four: "4",
        five: "5", six: "6", seven: "7", eight: "8", nine: "9",
      };
      const wordDigits = normalizeSpeech(spoken).split(" ")
        .map((word) => digitWords[word] || "").join("");
      const digits = spoken.replace(/[^\d]/g, "") || wordDigits;
      if (!digits) return false;
      target.value = mode === "phone" ? digits.slice(-10) : digits;
    } else if (mode === "date") {
      const today = new Date();
      let dateValue = "";
      if (/tomorrow/i.test(spoken)) {
        today.setDate(today.getDate() + 1);
        dateValue = today.toISOString().slice(0, 10);
      } else if (/today/i.test(spoken)) {
        dateValue = today.toISOString().slice(0, 10);
      } else {
        const parsed = new Date(spoken);
        if (!Number.isNaN(parsed.getTime())) dateValue = parsed.toISOString().slice(0, 10);
      }
      if (!dateValue) return false;
      target.value = dateValue;
    } else {
      target.value = spoken;
    }
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  document.querySelectorAll(".voice-input-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const target = document.getElementById(button.dataset.voiceTarget);
      if (!target) return;
      if (!SpeechRecognition) {
        const message = document.createElement("span");
        message.className = "voice-inline-status is-error";
        message.textContent = "Voice input needs Chrome or Edge.";
        button.parentElement.appendChild(message);
        setTimeout(() => message.remove(), 3500);
        return;
      }
      if (activeRecognition) {
        activeRecognition.stop();
        activeRecognition = null;
        if (activeVoiceButton) activeVoiceButton.classList.remove("is-listening");
      }

      const recognition = new SpeechRecognition();
      activeRecognition = recognition;
      activeVoiceButton = button;
      recognition.lang = speechLanguage();
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      button.classList.add("is-listening");
      button.textContent = "⏹️";

      const status = document.createElement("span");
      status.className = "voice-inline-status";
      status.textContent = "Listening…";
      button.parentElement.appendChild(status);

      recognition.onresult = (event) => {
        const transcript = event.results?.[0]?.[0]?.transcript || "";
        const ok = setSpokenValue(target, transcript, button.dataset.voiceMode);
        status.textContent = ok ? `Added: ${transcript}` : "Could not match that value. Try again.";
        status.classList.toggle("is-error", !ok);
      };
      recognition.onerror = (event) => {
        status.textContent = event.error === "not-allowed"
          ? "Microphone permission is blocked. Allow it in the browser."
          : "Voice input failed. Tap and try again.";
        status.classList.add("is-error");
      };
      recognition.onend = () => {
        button.classList.remove("is-listening");
        button.textContent = "🎙️";
        if (activeRecognition === recognition) activeRecognition = null;
        setTimeout(() => status.remove(), 4500);
      };
      try {
        recognition.start();
      } catch (error) {
        status.textContent = "Voice input could not start. Tap again.";
        status.classList.add("is-error");
        recognition.onend();
      }
    });
  });

  // ---------------------------------------------------------------- Entry form
  document.getElementById("form-entry").addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target;
    currentFarmerDetails = {
      name: form.name.value.trim(),
      state: form.state.value,
      crop: form.crop.value,
      qty: Number(form.qty.value),
      areaVillage: form.areaVillage.value.trim(),
      locationLat: farmerLocationCoords.lat,
      locationLng: farmerLocationCoords.lng,
    };
    await renderSlots();
    showScreen("slots");
  });

  // ---------------------------------------------------------------- Slot list
  async function renderSlots() {
    const list = document.getElementById("slots-list");
    list.innerHTML = `<p class="muted">Loading live wait times…</p>`;

    const options = nearMeCentreIds
      ? await Store.rankOptionsForCentres(nearMeCentreIds)
      : await Store.rankOptions(currentFarmerDetails.state);

    document.getElementById("slots-subline").textContent = nearMeCentreIds
      ? `Centres near you (${nearMeRadiusUsed ? `within ${nearMeRadiusUsed} km` : "closest available"}) for ${currentFarmerDetails.qty}q of ${currentFarmerDetails.crop}.`
      : `Best match for ${currentFarmerDetails.qty}q of ${currentFarmerDetails.crop} near ${currentFarmerDetails.areaVillage || "your area"}, ${currentFarmerDetails.state}.`;

    if (options.length === 0) {
      list.innerHTML = `<p class="muted">No procurement centres listed for ${currentFarmerDetails.state} yet.</p>`;
      return;
    }

    list.innerHTML = "";
    options.forEach((opt, i) => {
      const dist = nearMeDistances[opt.centre.id];
      const distanceTag = dist != null ? ` &middot; ${dist} km away` : "";
      const card = document.createElement("div");
      card.className = "slot-card" + (i === 0 ? " slot-card--recommended" : "");
      card.innerHTML = `
        <div class="slot-card__rank">${i + 1}</div>
        <div class="slot-card__body">
          <div class="slot-card__centre">${opt.centre.name} ${i === 0 ? '<span class="badge">Recommended</span>' : ''}</div>
          <div class="slot-card__meta">${opt.slot.label} &middot; ${opt.inQueue}/${opt.capacity} booked${opt.full ? " &middot; full, next slot suggested" : ""}${distanceTag}</div>
        </div>
        <div class="slot-card__wait">
          <div class="slot-card__waitnum">${opt.waitMins}<span> min wait</span></div>
        </div>
        <button class="btn btn--primary slot-card__book" ${opt.full ? "disabled" : ""}>Book</button>
      `;
      card.querySelector("button").addEventListener("click", () => bookSlot(opt));
      list.appendChild(card);
    });
  }

  async function bookSlot(opt) {
    const { token } = await Store.addBooking({
      centreId: opt.centre.id,
      slotId: opt.slot.id,
      farmer: currentFarmerDetails.name,
      state: currentFarmerDetails.state,
      areaVillage: currentFarmerDetails.areaVillage,
      crop: currentFarmerDetails.crop,
      qty: currentFarmerDetails.qty,
      locationLat: currentFarmerDetails.locationLat,
      locationLng: currentFarmerDetails.locationLng,
    });
    currentBookingToken = token;
    await renderToken();
    showScreen("token");
    if (tokenPollTimer) clearInterval(tokenPollTimer);
    tokenPollTimer = setInterval(renderToken, 3000);
  }

  async function renderToken() {
    const booking = await Store.getBooking(currentBookingToken);
    document.getElementById("tk-number").textContent = booking.token;
    document.getElementById("tk-name").textContent = booking.name;
    document.getElementById("tk-state").textContent = booking.state;
    document.getElementById("tk-village").textContent = booking.areaVillage;
    document.getElementById("tk-centre").textContent = booking.centreName;
    document.getElementById("tk-slot").textContent = booking.slotLabel;
    document.getElementById("tk-crop").textContent = booking.crop;
    document.getElementById("tk-qty").textContent = booking.qty + " quintals";
    document.getElementById("tk-ahead").textContent = booking.status === "submitted" ? booking.ahead : "0 — you're in";
    document.getElementById("tk-eta").textContent = booking.status === "submitted" ? booking.callTime : "Arrived";
    const order = ["submitted", "verified", "weighed", "paid"];
    const curIdx = order.indexOf(booking.status);
    document.querySelectorAll("#tk-stepper .stepper__step").forEach((el) => {
      const stepIdx = order.indexOf(el.dataset.step);
      el.classList.remove("is-done", "is-current");
      if (stepIdx < curIdx) el.classList.add("is-done");
      else if (stepIdx === curIdx) el.classList.add(booking.status === "paid" ? "is-done" : "is-current");
    });
  }

  document.getElementById("btn-new-booking").addEventListener("click", () => {
    if (tokenPollTimer) clearInterval(tokenPollTimer);
    document.getElementById("form-entry").reset();
    farmerLocationCoords = { lat: null, lng: null };
    farmerLocationAccuracy = null;
    nearMeCentreIds = null;
    nearMeDistances = {};
    showScreen("entry");
  });

  // ---------------------------------------------------------------- Transport booking
  const transportScreens = {
    entry: document.getElementById("screen-transport-entry"),
    confirmation: document.getElementById("screen-transport-confirmation"),
  };
  let pickupCoords = { lat: null, lng: null };
  let dropCoords = { lat: null, lng: null };

  function showTransportScreen(name) {
    Object.entries(transportScreens).forEach(([key, el]) => { el.hidden = key !== name; });
  }

  async function fillTransportLocation(kind) {
    const isPickup = kind === "pickup";
    const button = document.getElementById(`btn-${kind}-location`);
    const status = document.getElementById(`${kind}-location-status`);
    const input = document.getElementById(`t-${kind}-address`);
    button.disabled = true;
    status.textContent = "Finding live location…";
    try {
      const { position, source, fallbackPlace } = await getPositionWithFallback();
      const { latitude, longitude, accuracy } = position.coords;
      const coords = { lat: latitude, lng: longitude };
      if (isPickup) pickupCoords = coords;
      else dropCoords = coords;
      let place = fallbackPlace || {};
      try {
        place = await Store.reverseGeocode(latitude, longitude);
      } catch (error) {
        console.warn("Reverse geocoding failed", error);
      }
      const label = place.displayName || [place.village, place.district, place.state]
        .filter(Boolean).join(", ");
      input.value = label || `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
      if (isPickup) {
        const areaInput = document.getElementById("t-area-village");
        const matchedState = findMatchingState(place.state);
        areaInput.value = place.village || place.district || areaInput.value;
        if (matchedState) {
          transportStateSelect.value = matchedState;
          await refreshTransportProduceForState(matchedState);
        }
      }
      const accuracyText = Number.isFinite(accuracy) ? ` · ±${Math.round(accuracy)} m` : "";
      status.textContent = `${source} added${place.village ? `: ${place.village}` : ""}${accuracyText}.`;
    } catch (error) {
      console.error("Transport location failed", error);
      status.textContent = "Location unavailable. Type this address manually.";
    } finally {
      button.disabled = false;
    }
  }

  document.getElementById("btn-pickup-location").addEventListener("click", () => fillTransportLocation("pickup"));
  document.getElementById("btn-drop-location").addEventListener("click", () => fillTransportLocation("drop"));

  const dateInput = document.getElementById("t-date");
  const today = new Date();
  dateInput.min = today.toISOString().slice(0, 10);
  dateInput.value = dateInput.min;

  document.getElementById("form-transport").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.target;
    const errorBox = document.getElementById("transport-form-error");
    errorBox.hidden = true;
    const submitButton = form.querySelector("button[type='submit']");
    submitButton.disabled = true;
    submitButton.textContent = "Sending request…";

    try {
      const booking = await Store.addTransportBooking({
        farmer: form.farmer.value.trim(),
        phone: form.phone.value.trim(),
        state: form.state.value,
        areaVillage: form.areaVillage.value.trim(),
        vehicleType: form.vehicleType.value,
        pickupAddress: form.pickupAddress.value.trim(),
        pickupLat: pickupCoords.lat,
        pickupLng: pickupCoords.lng,
        dropAddress: form.dropAddress.value.trim(),
        dropLat: dropCoords.lat,
        dropLng: dropCoords.lng,
        produce: form.produce.value.trim(),
        qty: Number(form.qty.value),
        pickupDate: form.pickupDate.value,
      });
      document.getElementById("transport-code").textContent = booking.bookingCode;
      document.getElementById("transport-farmer").textContent = booking.farmer;
      document.getElementById("transport-state").textContent = booking.state;
      document.getElementById("transport-area-village").textContent = booking.areaVillage;
      document.getElementById("transport-vehicle").textContent = booking.vehicleType;
      document.getElementById("transport-produce").textContent = booking.produce;
      document.getElementById("transport-qty").textContent = `${booking.qty} quintals`;
      document.getElementById("transport-pickup").textContent = booking.pickupAddress;
      document.getElementById("transport-drop").textContent = booking.dropAddress;
      document.getElementById("transport-date").textContent = booking.pickupDate;
      showTransportScreen("confirmation");
    } catch (error) {
      errorBox.textContent = error.message || "Could not create the transport booking.";
      errorBox.hidden = false;
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = "Request vehicle";
    }
  });

  document.getElementById("btn-new-transport").addEventListener("click", () => {
    document.getElementById("form-transport").reset();
    dateInput.value = dateInput.min;
    pickupCoords = { lat: null, lng: null };
    dropCoords = { lat: null, lng: null };
    document.getElementById("pickup-location-status").textContent = "";
    document.getElementById("drop-location-status").textContent = "";
    document.querySelectorAll(".voice-inline-status").forEach((status) => status.remove());
    showTransportScreen("entry");
  });

  // ---------------------------------------------------------------- Admin view
  const centreSelect = document.getElementById("admin-centre-select");
  Store.centres.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c.id; opt.textContent = `${c.name} (${c.state})`;
    centreSelect.appendChild(opt);
  });
  centreSelect.addEventListener("change", renderAdmin);

  async function renderAdmin() {
    const centreId = centreSelect.value || Store.centres[0].id;
    centreSelect.value = centreId;
    const { centre, bookings, totalCapacity, totalBooked } = await Store.getCentreQueue(centreId);

    const pct = Math.min(100, Math.round((totalBooked / totalCapacity) * 100));
    const submittedCount = bookings.filter((booking) => booking.status === "submitted").length;
    const queueSignal = pct >= 85 ? "Critical" : pct >= 55 ? "Busy" : "Calm";
    document.getElementById("admin-stat-total").textContent = totalBooked;
    document.getElementById("admin-stat-capacity").textContent = `${pct}%`;
    document.getElementById("admin-stat-capacity-detail").textContent = `${totalBooked} / ${totalCapacity} slots used`;
    document.getElementById("admin-stat-queue").textContent = queueSignal;
    document.getElementById("admin-stat-queue-detail").textContent =
      `${submittedCount} farmer${submittedCount === 1 ? "" : "s"} waiting for verification`;
    document.getElementById("admin-capacity").innerHTML = `
      <div style="display:flex;justify-content:space-between;font-size:0.88rem;">
        <span><strong>${centre.name}</strong> &mdash; today's bookings</span>
        <span>${totalBooked} / ${totalCapacity}</span>
      </div>
      <div class="capacity-bar__track"><div class="capacity-bar__fill" style="width:${pct}%"></div></div>
    `;

    const alertBox = document.getElementById("admin-alert");
    if (pct >= 85) {
      alertBox.hidden = false;
      alertBox.textContent = `Centre nearing capacity (${pct}% booked). Farmer app will start recommending nearby centres.`;
    } else {
      alertBox.hidden = true;
    }

    const body = document.getElementById("admin-queue-body");
    body.innerHTML = "";
    const nextLabel = { submitted: "Verify", verified: "Weigh", weighed: "Mark paid", paid: null };
    bookings.forEach((b) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${b.token}</td>
        <td>${b.farmer}</td>
        <td>${b.crop}</td>
        <td>${b.qty}</td>
        <td>${b.slotLabel}</td>
        <td><span class="status-pill ${b.status === 'paid' ? 'status-pill--paid' : ''}">${labelFor(b.status)}</span></td>
        <td>${nextLabel[b.status] ? `<button class="btn--advance">${nextLabel[b.status]}</button>` : ""}</td>
      `;
      const advanceBtn = tr.querySelector(".btn--advance");
      if (advanceBtn) {
        advanceBtn.addEventListener("click", async () => {
          await Store.advanceStatus(b.token);
          renderAdmin();
        });
      }
      body.appendChild(tr);
    });
  }

  function labelFor(status) {
    return { submitted: "Submitted", verified: "Verified", weighed: "Weighed", paid: "Paid" }[status] || status;
  }
})();
